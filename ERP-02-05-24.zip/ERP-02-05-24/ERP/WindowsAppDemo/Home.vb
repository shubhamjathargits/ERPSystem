﻿Public Class Form1
    Private Sub ToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem1.Click
        Dim ItemMaster As New ItemMaster()
        ItemMaster.Show()
    End Sub

    Private Sub ShowDBToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowDBToolStripMenuItem.Click
        Dim Form2Instance As New ItemDetails()
        Form2Instance.Show()
    End Sub


    Private Sub CustomerMasterToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CustomerMasterToolStripMenuItem.Click
        Dim Form4Instance As New CustomerMaster()
        Form4Instance.Show()
    End Sub

    Private Sub SalesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SalesToolStripMenuItem.Click
        Dim Form5Instance As New SalesInvoice()
        Form5Instance.Show()
    End Sub
End Class
