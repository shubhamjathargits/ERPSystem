﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ItemMaster
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MfrMasterBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DemoItemDataSet = New WindowsAppDemo.DemoItemDataSet()
        Me.ItemtypeMasterBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DemoItemDataSet3 = New WindowsAppDemo.DemoItemDataSet3()
        Me.ShubhamDataSet = New WindowsAppDemo.ShubhamDataSet()
        Me.ShubhamDataSetBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ShubhamDataSetBindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        Me.MfrMasterTableAdapter = New WindowsAppDemo.DemoItemDataSetTableAdapters.MfrMasterTableAdapter()
        Me.DemoItemDataSet2 = New WindowsAppDemo.DemoItemDataSet2()
        Me.DemoItemDataSet2BindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ItemtypeMasterTableAdapter = New WindowsAppDemo.DemoItemDataSet3TableAdapters.ItemtypeMasterTableAdapter()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.ItemID = New System.Windows.Forms.TextBox()
        Me.Description = New System.Windows.Forms.TextBox()
        Me.Pakage = New System.Windows.Forms.TextBox()
        Me.Godown = New System.Windows.Forms.TextBox()
        Me.Unit = New System.Windows.Forms.TextBox()
        Me.ItemName = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.clear = New System.Windows.Forms.Button()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Manufature = New System.Windows.Forms.ComboBox()
        Me.Iteamtype = New System.Windows.Forms.ComboBox()
        Me.Update = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        CType(Me.MfrMasterBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ItemtypeMasterBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShubhamDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShubhamDataSetBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ShubhamDataSetBindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet2BindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MfrMasterBindingSource
        '
        Me.MfrMasterBindingSource.DataMember = "MfrMaster"
        Me.MfrMasterBindingSource.DataSource = Me.DemoItemDataSet
        '
        'DemoItemDataSet
        '
        Me.DemoItemDataSet.DataSetName = "DemoItemDataSet"
        Me.DemoItemDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ItemtypeMasterBindingSource
        '
        Me.ItemtypeMasterBindingSource.DataMember = "ItemtypeMaster"
        Me.ItemtypeMasterBindingSource.DataSource = Me.DemoItemDataSet3
        '
        'DemoItemDataSet3
        '
        Me.DemoItemDataSet3.DataSetName = "DemoItemDataSet3"
        Me.DemoItemDataSet3.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ShubhamDataSet
        '
        Me.ShubhamDataSet.DataSetName = "ShubhamDataSet"
        Me.ShubhamDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ShubhamDataSetBindingSource
        '
        Me.ShubhamDataSetBindingSource.DataSource = Me.ShubhamDataSet
        Me.ShubhamDataSetBindingSource.Position = 0
        '
        'ShubhamDataSetBindingSource1
        '
        Me.ShubhamDataSetBindingSource1.DataSource = Me.ShubhamDataSet
        Me.ShubhamDataSetBindingSource1.Position = 0
        '
        'MfrMasterTableAdapter
        '
        Me.MfrMasterTableAdapter.ClearBeforeFill = True
        '
        'DemoItemDataSet2
        '
        Me.DemoItemDataSet2.DataSetName = "DemoItemDataSet2"
        Me.DemoItemDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DemoItemDataSet2BindingSource
        '
        Me.DemoItemDataSet2BindingSource.DataSource = Me.DemoItemDataSet2
        Me.DemoItemDataSet2BindingSource.Position = 0
        '
        'ItemtypeMasterTableAdapter
        '
        Me.ItemtypeMasterTableAdapter.ClearBeforeFill = True
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.Menu
        Me.TextBox1.Location = New System.Drawing.Point(2, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(802, 31)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "ItemMaster"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ItemID
        '
        Me.ItemID.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.ItemID.Cursor = System.Windows.Forms.Cursors.No
        Me.ItemID.Location = New System.Drawing.Point(372, 76)
        Me.ItemID.Name = "ItemID"
        Me.ItemID.ReadOnly = True
        Me.ItemID.Size = New System.Drawing.Size(185, 20)
        Me.ItemID.TabIndex = 1
        Me.ItemID.Visible = False
        '
        'Description
        '
        Me.Description.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Description.Location = New System.Drawing.Point(372, 214)
        Me.Description.Name = "Description"
        Me.Description.Size = New System.Drawing.Size(185, 20)
        Me.Description.TabIndex = 2
        '
        'Pakage
        '
        Me.Pakage.Location = New System.Drawing.Point(372, 282)
        Me.Pakage.Name = "Pakage"
        Me.Pakage.Size = New System.Drawing.Size(185, 20)
        Me.Pakage.TabIndex = 3
        '
        'Godown
        '
        Me.Godown.Location = New System.Drawing.Point(372, 249)
        Me.Godown.Name = "Godown"
        Me.Godown.Size = New System.Drawing.Size(185, 20)
        Me.Godown.TabIndex = 4
        '
        'Unit
        '
        Me.Unit.Location = New System.Drawing.Point(372, 313)
        Me.Unit.Name = "Unit"
        Me.Unit.Size = New System.Drawing.Size(185, 20)
        Me.Unit.TabIndex = 5
        '
        'ItemName
        '
        Me.ItemName.Location = New System.Drawing.Point(372, 113)
        Me.ItemName.Name = "ItemName"
        Me.ItemName.Size = New System.Drawing.Size(185, 20)
        Me.ItemName.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(290, 83)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Item ID"
        Me.Label1.Visible = False
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(298, 285)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(50, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Pakage"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(277, 217)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(71, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Description"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(285, 179)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(63, 13)
        Me.Label4.TabIndex = 10
        Me.Label4.Text = "Item Type" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(285, 116)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 11
        Me.Label5.Text = "Item Name"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(281, 146)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(71, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "Manufature" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(295, 252)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(53, 13)
        Me.Label7.TabIndex = 13
        Me.Label7.Text = "Godown"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(318, 316)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(30, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Unit"
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.Green
        Me.Button1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.Location = New System.Drawing.Point(301, 369)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(80, 33)
        Me.Button1.TabIndex = 16
        Me.Button1.Text = "Save"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'clear
        '
        Me.clear.BackColor = System.Drawing.Color.Teal
        Me.clear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.clear.Location = New System.Drawing.Point(521, 369)
        Me.clear.Name = "clear"
        Me.clear.Size = New System.Drawing.Size(75, 33)
        Me.clear.TabIndex = 18
        Me.clear.Text = "Clear"
        Me.clear.UseVisualStyleBackColor = False
        '
        'Delete
        '
        Me.Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Delete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Delete.Location = New System.Drawing.Point(413, 369)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(77, 33)
        Me.Delete.TabIndex = 19
        Me.Delete.Text = "Delete"
        Me.Delete.UseVisualStyleBackColor = False
        '
        'Manufature
        '
        Me.Manufature.DataSource = Me.MfrMasterBindingSource
        Me.Manufature.DisplayMember = "Mfrname"
        Me.Manufature.FormattingEnabled = True
        Me.Manufature.Location = New System.Drawing.Point(372, 146)
        Me.Manufature.Name = "Manufature"
        Me.Manufature.Size = New System.Drawing.Size(185, 21)
        Me.Manufature.TabIndex = 20
        '
        'Iteamtype
        '
        Me.Iteamtype.AccessibleRole = System.Windows.Forms.AccessibleRole.None
        Me.Iteamtype.DataSource = Me.ItemtypeMasterBindingSource
        Me.Iteamtype.DisplayMember = "Itemtype"
        Me.Iteamtype.FormattingEnabled = True
        Me.Iteamtype.Location = New System.Drawing.Point(372, 179)
        Me.Iteamtype.Name = "Iteamtype"
        Me.Iteamtype.Size = New System.Drawing.Size(185, 21)
        Me.Iteamtype.TabIndex = 21
        '
        'Update
        '
        Me.Update.BackColor = System.Drawing.Color.Gold
        Me.Update.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Update.Location = New System.Drawing.Point(301, 369)
        Me.Update.Name = "Update"
        Me.Update.Size = New System.Drawing.Size(80, 33)
        Me.Update.TabIndex = 22
        Me.Update.Text = "Modify"
        Me.Update.UseVisualStyleBackColor = False
        Me.Update.Visible = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(372, 135)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(298, 108)
        Me.ListBox1.TabIndex = 23
        Me.ListBox1.Visible = False
        '
        'ItemMaster
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(799, 561)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Update)
        Me.Controls.Add(Me.Iteamtype)
        Me.Controls.Add(Me.Manufature)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.clear)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.ItemName)
        Me.Controls.Add(Me.Unit)
        Me.Controls.Add(Me.Godown)
        Me.Controls.Add(Me.Pakage)
        Me.Controls.Add(Me.Description)
        Me.Controls.Add(Me.ItemID)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "ItemMaster"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ItemMaster"
        CType(Me.MfrMasterBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ItemtypeMasterBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShubhamDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShubhamDataSetBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ShubhamDataSetBindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet2BindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ShubhamDataSet As ShubhamDataSet
    Friend WithEvents ShubhamDataSetBindingSource As BindingSource
    Friend WithEvents ShubhamDataSetBindingSource1 As BindingSource
    Friend WithEvents DemoItemDataSet As DemoItemDataSet
    Friend WithEvents MfrMasterBindingSource As BindingSource
    Friend WithEvents MfrMasterTableAdapter As DemoItemDataSetTableAdapters.MfrMasterTableAdapter
    Friend WithEvents DemoItemDataSet2 As DemoItemDataSet2
    Friend WithEvents DemoItemDataSet2BindingSource As BindingSource
    Friend WithEvents DemoItemDataSet3 As DemoItemDataSet3
    Friend WithEvents ItemtypeMasterBindingSource As BindingSource
    Friend WithEvents ItemtypeMasterTableAdapter As DemoItemDataSet3TableAdapters.ItemtypeMasterTableAdapter
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents ItemID As TextBox
    Friend WithEvents Description As TextBox
    Friend WithEvents Pakage As TextBox
    Friend WithEvents Godown As TextBox
    Friend WithEvents Unit As TextBox
    Friend WithEvents ItemName As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents clear As Button
    Friend WithEvents Delete As Button
    Friend WithEvents Manufature As ComboBox
    Friend WithEvents Iteamtype As ComboBox
    Friend WithEvents Update As Button
    Friend WithEvents ListBox1 As ListBox
End Class
