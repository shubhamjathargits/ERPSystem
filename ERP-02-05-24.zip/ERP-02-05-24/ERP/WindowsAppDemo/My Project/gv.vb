﻿Public Class gv
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        ' Add a new row with TextBox1 and TextBox2 values
        Me.DataGridView1.Rows.Add(TextBox1.Text, TextBox2.Text)
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Check if any rows are selected
        If DataGridView1.SelectedRows.Count > 0 Then
            ' Iterate through selected rows in reverse order and remove them
            For i As Integer = DataGridView1.SelectedRows.Count - 1 To 0 Step -1
                DataGridView1.Rows.RemoveAt(DataGridView1.SelectedRows(i).Index)
            Next
        Else
            ' Show a message if no rows are selected
            MessageBox.Show("Select Row")
        End If
    End Sub
End Class
