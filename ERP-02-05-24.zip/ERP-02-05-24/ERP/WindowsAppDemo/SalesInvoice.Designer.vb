﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class SalesInvoice
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Cust_name = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.cust = New System.Windows.Forms.TextBox()
        Me.Billno = New System.Windows.Forms.TextBox()
        Me.itemtype = New System.Windows.Forms.TextBox()
        Me.Mobile_number = New System.Windows.Forms.TextBox()
        Me.address = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Itemname = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.qty = New System.Windows.Forms.TextBox()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.DateTimePicker1 = New System.Windows.Forms.DateTimePicker()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Price = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Discount = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.TotalAmt = New System.Windows.Forms.TextBox()
        Me.DisAmt = New System.Windows.Forms.TextBox()
        Me.GSTAmt = New System.Windows.Forms.TextBox()
        Me.NetbillAmt = New System.Windows.Forms.TextBox()
        Me.Save = New System.Windows.Forms.Button()
        Me.Close = New System.Windows.Forms.Button()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Clear = New System.Windows.Forms.Button()
        Me.Modify = New System.Windows.Forms.Button()
        Me.print = New System.Windows.Forms.Button()
        Me.Whatsapp = New System.Windows.Forms.PictureBox()
        Me.Gmail = New System.Windows.Forms.PictureBox()
        Me.notGST = New System.Windows.Forms.CheckBox()
        Me.Client_id = New System.Windows.Forms.TextBox()
        Me.ListBox3 = New System.Windows.Forms.ListBox()
        Me.ItemID = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Sr_No = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Item_name = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Manufature = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Item_type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Batch = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Godown = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.qtty = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.price1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.discount1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DiscountAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GST = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GSTAmount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Total_amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SGST_per = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SGST_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CGST_per = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CGST_Amount = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DeleteRow = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Whatsapp, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Gmail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.MenuText
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.Window
        Me.TextBox1.Location = New System.Drawing.Point(0, 12)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(801, 24)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "Sales Invoice"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Cust_name
        '
        Me.Cust_name.AutoSize = True
        Me.Cust_name.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Cust_name.Location = New System.Drawing.Point(121, 54)
        Me.Cust_name.Name = "Cust_name"
        Me.Cust_name.Size = New System.Drawing.Size(95, 13)
        Me.Cust_name.TabIndex = 1
        Me.Cust_name.Text = "Customer Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(121, 114)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Mobile Number"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(121, 82)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(52, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Address"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(434, 82)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Date"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(420, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Bill No."
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(420, 54)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Item Type"
        '
        'cust
        '
        Me.cust.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cust.Location = New System.Drawing.Point(233, 47)
        Me.cust.Name = "cust"
        Me.cust.Size = New System.Drawing.Size(159, 24)
        Me.cust.TabIndex = 7
        '
        'Billno
        '
        Me.Billno.AccessibleName = "Billno"
        Me.Billno.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        Me.Billno.Enabled = False
        Me.Billno.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Billno.Location = New System.Drawing.Point(489, 107)
        Me.Billno.Name = "Billno"
        Me.Billno.Size = New System.Drawing.Size(159, 24)
        Me.Billno.TabIndex = 8
        '
        'itemtype
        '
        Me.itemtype.BackColor = System.Drawing.SystemColors.InactiveCaption
        Me.itemtype.Enabled = False
        Me.itemtype.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.itemtype.Location = New System.Drawing.Point(489, 47)
        Me.itemtype.Name = "itemtype"
        Me.itemtype.Size = New System.Drawing.Size(159, 24)
        Me.itemtype.TabIndex = 9
        Me.itemtype.Text = "Common"
        '
        'Mobile_number
        '
        Me.Mobile_number.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Mobile_number.Location = New System.Drawing.Point(233, 107)
        Me.Mobile_number.Name = "Mobile_number"
        Me.Mobile_number.Size = New System.Drawing.Size(159, 24)
        Me.Mobile_number.TabIndex = 10
        '
        'address
        '
        Me.address.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.address.Location = New System.Drawing.Point(233, 75)
        Me.address.Name = "address"
        Me.address.Size = New System.Drawing.Size(159, 24)
        Me.address.TabIndex = 11
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(22, 155)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(63, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "ItemName"
        '
        'DataGridView1
        '
        Me.DataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.ItemID, Me.Sr_No, Me.Item_name, Me.Manufature, Me.Item_type, Me.Batch, Me.Godown, Me.qtty, Me.price1, Me.discount1, Me.DiscountAmount, Me.GST, Me.GSTAmount, Me.Amount, Me.Total_amount, Me.SGST_per, Me.SGST_Amount, Me.CGST_per, Me.CGST_Amount, Me.DeleteRow})
        Me.DataGridView1.Location = New System.Drawing.Point(7, 178)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(789, 150)
        Me.DataGridView1.TabIndex = 13
        '
        'Itemname
        '
        Me.Itemname.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Itemname.Location = New System.Drawing.Point(91, 150)
        Me.Itemname.Name = "Itemname"
        Me.Itemname.Size = New System.Drawing.Size(136, 24)
        Me.Itemname.TabIndex = 14
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(272, 155)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(32, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "QTY"
        '
        'qty
        '
        Me.qty.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.qty.Location = New System.Drawing.Point(310, 148)
        Me.qty.Name = "qty"
        Me.qty.Size = New System.Drawing.Size(54, 24)
        Me.qty.TabIndex = 16
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(233, 70)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(180, 95)
        Me.ListBox1.TabIndex = 17
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(91, 171)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(335, 108)
        Me.ListBox2.TabIndex = 18
        Me.ListBox2.Visible = False
        '
        'DateTimePicker1
        '
        Me.DateTimePicker1.AccessibleName = "Date"
        Me.DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DateTimePicker1.Location = New System.Drawing.Point(489, 82)
        Me.DateTimePicker1.Name = "DateTimePicker1"
        Me.DateTimePicker1.Size = New System.Drawing.Size(159, 20)
        Me.DateTimePicker1.TabIndex = 19
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(423, 155)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(36, 13)
        Me.Label8.TabIndex = 20
        Me.Label8.Text = "Price"
        '
        'Price
        '
        Me.Price.AccessibleName = "Price"
        Me.Price.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Price.Location = New System.Drawing.Point(474, 150)
        Me.Price.Name = "Price"
        Me.Price.Size = New System.Drawing.Size(54, 24)
        Me.Price.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(575, 155)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(41, 13)
        Me.Label9.TabIndex = 22
        Me.Label9.Text = "Disc%"
        '
        'Discount
        '
        Me.Discount.AccessibleName = "Discount"
        Me.Discount.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Discount.Location = New System.Drawing.Point(619, 150)
        Me.Discount.Name = "Discount"
        Me.Discount.Size = New System.Drawing.Size(54, 24)
        Me.Discount.TabIndex = 23
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(113, 383)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(103, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Discount Amount"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(450, 352)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(78, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "GST Amount"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(122, 352)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 13)
        Me.Label13.TabIndex = 27
        Me.Label13.Text = "Net Bill Amount"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(446, 383)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(82, 13)
        Me.Label14.TabIndex = 28
        Me.Label14.Text = "Total Amount"
        '
        'TotalAmt
        '
        Me.TotalAmt.BackColor = System.Drawing.Color.Gainsboro
        Me.TotalAmt.Enabled = False
        Me.TotalAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TotalAmt.Location = New System.Drawing.Point(541, 376)
        Me.TotalAmt.Name = "TotalAmt"
        Me.TotalAmt.Size = New System.Drawing.Size(159, 24)
        Me.TotalAmt.TabIndex = 29
        Me.TotalAmt.Text = "0"
        '
        'DisAmt
        '
        Me.DisAmt.BackColor = System.Drawing.Color.Gainsboro
        Me.DisAmt.Enabled = False
        Me.DisAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.DisAmt.Location = New System.Drawing.Point(233, 376)
        Me.DisAmt.Name = "DisAmt"
        Me.DisAmt.Size = New System.Drawing.Size(159, 24)
        Me.DisAmt.TabIndex = 33
        Me.DisAmt.Text = "0"
        '
        'GSTAmt
        '
        Me.GSTAmt.BackColor = System.Drawing.Color.Gainsboro
        Me.GSTAmt.Enabled = False
        Me.GSTAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GSTAmt.Location = New System.Drawing.Point(541, 341)
        Me.GSTAmt.Name = "GSTAmt"
        Me.GSTAmt.Size = New System.Drawing.Size(159, 24)
        Me.GSTAmt.TabIndex = 34
        Me.GSTAmt.Text = "0"
        '
        'NetbillAmt
        '
        Me.NetbillAmt.BackColor = System.Drawing.Color.Gainsboro
        Me.NetbillAmt.Enabled = False
        Me.NetbillAmt.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.NetbillAmt.ForeColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.NetbillAmt.Location = New System.Drawing.Point(233, 346)
        Me.NetbillAmt.Name = "NetbillAmt"
        Me.NetbillAmt.Size = New System.Drawing.Size(159, 24)
        Me.NetbillAmt.TabIndex = 35
        Me.NetbillAmt.Text = "0"
        '
        'Save
        '
        Me.Save.BackColor = System.Drawing.Color.Green
        Me.Save.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Save.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Save.Location = New System.Drawing.Point(25, 427)
        Me.Save.Name = "Save"
        Me.Save.Size = New System.Drawing.Size(84, 32)
        Me.Save.TabIndex = 36
        Me.Save.Text = "Save"
        Me.Save.UseVisualStyleBackColor = False
        '
        'Close
        '
        Me.Close.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Close.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Close.Location = New System.Drawing.Point(474, 427)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(84, 32)
        Me.Close.TabIndex = 37
        Me.Close.Text = "Close"
        Me.Close.UseVisualStyleBackColor = False
        '
        'Delete
        '
        Me.Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Delete.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Delete.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Delete.Location = New System.Drawing.Point(251, 427)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(84, 32)
        Me.Delete.TabIndex = 38
        Me.Delete.Text = "Delete"
        Me.Delete.UseVisualStyleBackColor = False
        '
        'Clear
        '
        Me.Clear.BackColor = System.Drawing.Color.DodgerBlue
        Me.Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Clear.Location = New System.Drawing.Point(363, 427)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(84, 32)
        Me.Clear.TabIndex = 39
        Me.Clear.Text = "Clear"
        Me.Clear.UseVisualStyleBackColor = False
        '
        'Modify
        '
        Me.Modify.BackColor = System.Drawing.Color.Yellow
        Me.Modify.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modify.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Modify.Location = New System.Drawing.Point(143, 427)
        Me.Modify.Name = "Modify"
        Me.Modify.Size = New System.Drawing.Size(84, 32)
        Me.Modify.TabIndex = 40
        Me.Modify.Text = "Modify"
        Me.Modify.UseVisualStyleBackColor = False
        '
        'print
        '
        Me.print.BackColor = System.Drawing.Color.RoyalBlue
        Me.print.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.print.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.print.Location = New System.Drawing.Point(578, 427)
        Me.print.Name = "print"
        Me.print.Size = New System.Drawing.Size(84, 32)
        Me.print.TabIndex = 41
        Me.print.Text = "Print"
        Me.print.UseVisualStyleBackColor = False
        '
        'Whatsapp
        '
        Me.Whatsapp.Image = Global.WindowsAppDemo.My.Resources.Resources._580b57fcd9996e24bc43c5431
        Me.Whatsapp.Location = New System.Drawing.Point(678, 425)
        Me.Whatsapp.Name = "Whatsapp"
        Me.Whatsapp.Size = New System.Drawing.Size(54, 34)
        Me.Whatsapp.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Whatsapp.TabIndex = 42
        Me.Whatsapp.TabStop = False
        '
        'Gmail
        '
        Me.Gmail.Image = Global.WindowsAppDemo.My.Resources.Resources._62bda0d7bafda8767a088b3e
        Me.Gmail.Location = New System.Drawing.Point(738, 425)
        Me.Gmail.Name = "Gmail"
        Me.Gmail.Size = New System.Drawing.Size(54, 34)
        Me.Gmail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.Gmail.TabIndex = 43
        Me.Gmail.TabStop = False
        '
        'notGST
        '
        Me.notGST.AutoSize = True
        Me.notGST.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.notGST.Location = New System.Drawing.Point(665, 114)
        Me.notGST.Name = "notGST"
        Me.notGST.Size = New System.Drawing.Size(118, 17)
        Me.notGST.TabIndex = 44
        Me.notGST.Text = "Don`t Appy GST"
        Me.notGST.UseVisualStyleBackColor = True
        '
        'Client_id
        '
        Me.Client_id.Location = New System.Drawing.Point(15, 47)
        Me.Client_id.Name = "Client_id"
        Me.Client_id.Size = New System.Drawing.Size(100, 20)
        Me.Client_id.TabIndex = 45
        Me.Client_id.Visible = False
        '
        'ListBox3
        '
        Me.ListBox3.FormattingEnabled = True
        Me.ListBox3.Location = New System.Drawing.Point(143, 285)
        Me.ListBox3.Name = "ListBox3"
        Me.ListBox3.Size = New System.Drawing.Size(313, 134)
        Me.ListBox3.TabIndex = 46
        Me.ListBox3.Visible = False
        '
        'ItemID
        '
        Me.ItemID.HeaderText = "Item ID"
        Me.ItemID.Name = "ItemID"
        Me.ItemID.ReadOnly = True
        Me.ItemID.Visible = False
        '
        'Sr_No
        '
        Me.Sr_No.HeaderText = "Sr.No"
        Me.Sr_No.Name = "Sr_No"
        Me.Sr_No.ReadOnly = True
        '
        'Item_name
        '
        Me.Item_name.HeaderText = "Item Name"
        Me.Item_name.Name = "Item_name"
        Me.Item_name.ReadOnly = True
        '
        'Manufature
        '
        Me.Manufature.HeaderText = "Manufature"
        Me.Manufature.Name = "Manufature"
        Me.Manufature.ReadOnly = True
        '
        'Item_type
        '
        Me.Item_type.HeaderText = "Item Type"
        Me.Item_type.Name = "Item_type"
        Me.Item_type.ReadOnly = True
        '
        'Batch
        '
        Me.Batch.HeaderText = "Batch"
        Me.Batch.Name = "Batch"
        Me.Batch.ReadOnly = True
        '
        'Godown
        '
        Me.Godown.HeaderText = "Godown"
        Me.Godown.Name = "Godown"
        Me.Godown.ReadOnly = True
        '
        'qtty
        '
        Me.qtty.HeaderText = "QTY"
        Me.qtty.Name = "qtty"
        '
        'price1
        '
        Me.price1.HeaderText = "Price"
        Me.price1.Name = "price1"
        '
        'discount1
        '
        Me.discount1.HeaderText = "Disc%"
        Me.discount1.Name = "discount1"
        '
        'DiscountAmount
        '
        Me.DiscountAmount.HeaderText = "Discount Amount"
        Me.DiscountAmount.Name = "DiscountAmount"
        Me.DiscountAmount.ReadOnly = True
        '
        'GST
        '
        Me.GST.HeaderText = "GST%"
        Me.GST.Name = "GST"
        Me.GST.ReadOnly = True
        '
        'GSTAmount
        '
        Me.GSTAmount.HeaderText = "GST Amt"
        Me.GSTAmount.Name = "GSTAmount"
        Me.GSTAmount.ReadOnly = True
        '
        'Amount
        '
        Me.Amount.HeaderText = "Amount"
        Me.Amount.Name = "Amount"
        Me.Amount.ReadOnly = True
        '
        'Total_amount
        '
        Me.Total_amount.HeaderText = "Toal Amt"
        Me.Total_amount.Name = "Total_amount"
        Me.Total_amount.ReadOnly = True
        '
        'SGST_per
        '
        Me.SGST_per.HeaderText = "SGST%"
        Me.SGST_per.Name = "SGST_per"
        Me.SGST_per.ReadOnly = True
        '
        'SGST_Amount
        '
        Me.SGST_Amount.HeaderText = "SGST Amount"
        Me.SGST_Amount.Name = "SGST_Amount"
        Me.SGST_Amount.ReadOnly = True
        '
        'CGST_per
        '
        Me.CGST_per.HeaderText = "CGST%"
        Me.CGST_per.Name = "CGST_per"
        Me.CGST_per.ReadOnly = True
        '
        'CGST_Amount
        '
        Me.CGST_Amount.HeaderText = "CGST Amount"
        Me.CGST_Amount.Name = "CGST_Amount"
        Me.CGST_Amount.ReadOnly = True
        '
        'DeleteRow
        '
        Me.DeleteRow.HeaderText = "Clear"
        Me.DeleteRow.Name = "DeleteRow"
        '
        'SalesInvoice
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(808, 462)
        Me.Controls.Add(Me.ListBox3)
        Me.Controls.Add(Me.Client_id)
        Me.Controls.Add(Me.notGST)
        Me.Controls.Add(Me.Gmail)
        Me.Controls.Add(Me.Whatsapp)
        Me.Controls.Add(Me.print)
        Me.Controls.Add(Me.Modify)
        Me.Controls.Add(Me.Clear)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.Close)
        Me.Controls.Add(Me.Save)
        Me.Controls.Add(Me.NetbillAmt)
        Me.Controls.Add(Me.GSTAmt)
        Me.Controls.Add(Me.DisAmt)
        Me.Controls.Add(Me.TotalAmt)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Discount)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Price)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.DateTimePicker1)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.qty)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Itemname)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.address)
        Me.Controls.Add(Me.Mobile_number)
        Me.Controls.Add(Me.itemtype)
        Me.Controls.Add(Me.Billno)
        Me.Controls.Add(Me.cust)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Cust_name)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "SalesInvoice"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SalesInvoice"
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Whatsapp, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Gmail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Cust_name As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents cust As TextBox
    Friend WithEvents Billno As TextBox
    Friend WithEvents itemtype As TextBox
    Friend WithEvents Mobile_number As TextBox
    Friend WithEvents address As TextBox
    Friend WithEvents Label6 As Label
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Itemname As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents qty As TextBox
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents DateTimePicker1 As DateTimePicker
    Friend WithEvents Label8 As Label
    Friend WithEvents Price As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Discount As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents TotalAmt As TextBox
    Friend WithEvents DisAmt As TextBox
    Friend WithEvents GSTAmt As TextBox
    Friend WithEvents NetbillAmt As TextBox
    Friend WithEvents Save As Button
    Friend WithEvents Close As Button
    Friend WithEvents Delete As Button
    Friend WithEvents Clear As Button
    Friend WithEvents Modify As Button
    Friend WithEvents print As Button
    Friend WithEvents Whatsapp As PictureBox
    Friend WithEvents Gmail As PictureBox
    Friend WithEvents notGST As CheckBox
    Friend WithEvents Client_id As TextBox
    Friend WithEvents ListBox3 As ListBox
    Friend WithEvents ItemID As DataGridViewTextBoxColumn
    Friend WithEvents Sr_No As DataGridViewTextBoxColumn
    Friend WithEvents Item_name As DataGridViewTextBoxColumn
    Friend WithEvents Manufature As DataGridViewTextBoxColumn
    Friend WithEvents Item_type As DataGridViewTextBoxColumn
    Friend WithEvents Batch As DataGridViewTextBoxColumn
    Friend WithEvents Godown As DataGridViewTextBoxColumn
    Friend WithEvents qtty As DataGridViewTextBoxColumn
    Friend WithEvents price1 As DataGridViewTextBoxColumn
    Friend WithEvents discount1 As DataGridViewTextBoxColumn
    Friend WithEvents DiscountAmount As DataGridViewTextBoxColumn
    Friend WithEvents GST As DataGridViewTextBoxColumn
    Friend WithEvents GSTAmount As DataGridViewTextBoxColumn
    Friend WithEvents Amount As DataGridViewTextBoxColumn
    Friend WithEvents Total_amount As DataGridViewTextBoxColumn
    Friend WithEvents SGST_per As DataGridViewTextBoxColumn
    Friend WithEvents SGST_Amount As DataGridViewTextBoxColumn
    Friend WithEvents CGST_per As DataGridViewTextBoxColumn
    Friend WithEvents CGST_Amount As DataGridViewTextBoxColumn
    Friend WithEvents DeleteRow As DataGridViewTextBoxColumn
End Class
