﻿Imports System.Data.SqlClient
Imports System.Globalization

Public Class SalesInvoice
    ' Define your connection string
    Private customerIdLoaded As Integer = 0
    Private dataLoaded As Boolean = False
    Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

    Private Async Sub SalesInvoice_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Initially, hide the ListBox
        Await Task.Delay(100)
        ' Set focus to the Customer Name textbox
        cust.Focus()
        ListBox1.Visible = False
        CalculateTotalAmount()

        ' Call the function to set the next bill number
        SetNextBillNumber()
    End Sub

    Private Sub SetNextBillNumber()
        Try
            ' Connect to the database
            Using connection As New SqlConnection(connectionString)
                ' Open the connection
                connection.Open()

                ' Define the SQL query to fetch the maximum bill number
                Dim query As String = "SELECT MAX(Bill_no) FROM SalesInvoiceMaster"

                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Execute the SQL command and retrieve the maximum bill number
                    Dim maxBillNo As Object = command.ExecuteScalar()

                    If maxBillNo IsNot DBNull.Value Then
                        ' If a maximum bill number exists, increment it by one
                        Dim nextBillNo As Integer = Convert.ToInt32(maxBillNo) + 1
                        ' Set the next bill number in the Billno textbox
                        Billno.Text = nextBillNo.ToString()
                    Else
                        ' If no bill number exists in the table, start from 1
                        Billno.Text = "1"
                    End If
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading bill number: " & ex.Message)
        End Try
    End Sub




    ' Declare a DataTable to hold your original data
    Private originalDataSource As New DataTable()

    ' Populate the DataGridView with data
    Private Sub PopulateDataGridView()
        ' Assuming you have already populated your DataTable or original data source
        ' Set the DataGridView's DataSource to the original data source
        DataGridView1.DataSource = originalDataSource
    End Sub

    ' Method to hide rows in a specific column
    Private Sub HideRowsInColumn(columnName As String)
        ' Assuming originalDataSource is your original data source
        Dim filteredView As New DataView(originalDataSource)

        ' Filter out rows where the specified column is empty or null
        filteredView.RowFilter = $"{columnName} IS NOT NULL AND {columnName} <> ''"

        ' Re-bind the DataGridView to the filtered view
        DataGridView1.DataSource = filteredView
    End Sub

    Private Sub Customer_name_TextChanged(sender As Object, e As EventArgs) Handles cust.TextChanged
        ' Check if the length of entered text is greater than 0
        If cust.Text.Length > 0 Then
            ' Check if the entered text matches any customer names in the database
            If CustomerNameExistsInDatabase(cust.Text.Trim()) Then
                ' Load and display customer data in ListBox
                LoadCustomerData(cust.Text.Trim())
                ListBox1.Visible = True
            Else
                ' Hide the ListBox if no similar customer names found
                ListBox1.Visible = False
            End If
        Else
            ' Hide the ListBox if the length of entered text is 0
            ListBox1.Visible = False
        End If
    End Sub


    Private Function CustomerNameExistsInDatabase(customerName As String) As Boolean
        Try
            ' Define your SQL query to check if customer name exists in the database
            Dim query As String = "SELECT COUNT(*) FROM CustomerMaster WHERE Customer_Name LIKE @CustomerName"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter value for the customer name
                    command.Parameters.AddWithValue("@CustomerName", customerName + "%") ' Add % wildcard to match names starting with the entered text

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command and retrieve the count of matching customer names
                    Dim count As Integer = CInt(command.ExecuteScalar())

                    ' Return true if at least one similar customer name exists in the database
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error checking customer name in database: " & ex.Message)
            Return False ' Return false in case of any exception
        End Try
    End Function

    Private Sub LoadCustomerData(searchText As String)
        Try
            ' Define your SQL query to select customer details based on the entered text
            Dim query As String = "SELECT Customer_Name, Address, Mobile_number FROM CustomerMaster WHERE Customer_Name LIKE @SearchText + '%'"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter value for the search text
                    command.Parameters.AddWithValue("@SearchText", searchText)

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command and retrieve the customer data
                    Using reader As SqlDataReader = command.ExecuteReader()
                        ' Clear the ListBox items
                        ListBox1.Items.Clear()

                        ' Loop through the results and add them to the ListBox
                        While reader.Read()
                            ' Concatenate customer details and add them to the ListBox
                            Dim customerDetails As String = $"{reader("Customer_Name")} : {reader("Address")} : {reader("Mobile_number")}"
                            ListBox1.Items.Add(customerDetails)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading customer data: " & ex.Message)
        End Try
    End Sub
    Private Sub ListBox1_DoubleClick(sender As Object, e As EventArgs) Handles ListBox1.DoubleClick
        ' Call the method to autofill the form fields when an item is double-clicked in the ListBox
        AutofillCustomerData()
    End Sub

    Private Sub ListBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox1.KeyDown
        ' Check if Enter key is pressed
        If e.KeyCode = Keys.Enter Then
            ' Call the method to autofill the form fields when Enter key is pressed in the ListBox
            AutofillCustomerData()
        End If
    End Sub

    Private Sub AutofillCustomerData()
        ' Check if an item is selected in the ListBox
        If ListBox1.SelectedIndex <> -1 Then
            ' Get the selected item from the ListBox
            Dim selectedItem As String = ListBox1.SelectedItem.ToString()

            ' Split the selected item to extract customer details
            Dim customerDetails() As String = selectedItem.Split(":"c)

            ' Autofill the form fields with the extracted customer details
            If customerDetails.Length >= 3 Then
                ' Trim to remove leading and trailing spaces
                cust.Text = customerDetails(0).Trim()
                address.Text = customerDetails(1).Trim()
                Mobile_number.Text = customerDetails(2).Trim()
                ListBox1.Visible = False
                customerIdLoaded = 1
            End If
        End If
    End Sub
    ' Add event handlers for other controls as needed

    Private Sub Customer_name_KeyDown(sender As Object, e As KeyEventArgs) Handles cust.KeyDown
        If ListBox1.Visible = True Then
            If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
                ListBox1.Focus()
                e.SuppressKeyPress = True
            End If
        ElseIf ListBox1.Visible = False Then
            If e.KeyCode = Keys.Down Then
                If customerIdLoaded = 0 Then
                    address.Focus()
                Else
                    DateTimePicker1.Focus()
                End If

            End If
            If e.KeyCode = Keys.Enter Then
                address.Focus()

                e.SuppressKeyPress = True
            End If
        End If
    End Sub

    Private Sub ListBox_KeyDown(sender As Object, e As KeyEventArgs)
        If e.KeyCode = Keys.Enter Then
            If ListBox1.SelectedIndex <> -1 Then
                AutofillCustomerData()
                ListBox1.Visible = False
                cust.Focus()
                e.SuppressKeyPress = True
            End If
        ElseIf e.KeyCode = Keys.Down Then
            If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
                e.SuppressKeyPress = True
                Return ' Do not move selection further down
            End If
        ElseIf e.KeyCode = Keys.Enter Then
            Mobile_number.Focus()
            ListBox1.Visible = False
        End If
        If e.KeyCode = Keys.Up Then
            cust.Focus()
        End If
    End Sub
    Private Sub Itemname_TextChanged(sender As Object, e As EventArgs) Handles Itemname.TextChanged
        ' Check if the length of entered text is greater than 0
        If Itemname.Text.Length > 0 Then
            ' Check if the entered text matches any item names in the database
            If ItemNameExistsInDatabase(Itemname.Text.Trim()) Then
                ' Load and display item names in ListBox2
                LoadItemNames(Itemname.Text.Trim())
                ListBox2.Visible = True

                ' If there's only one item in the ListBox2, autofill and select it
                If ListBox2.Items.Count >= 1 Then
                    AutofillItemData()
                    ListBox2.SelectedIndex = 0
                End If
            Else
                ' Hide ListBox2 if no similar item names found
                ListBox2.Visible = False
            End If
        Else
            ' Hide ListBox2 if the length of entered text is 0
            ListBox2.Visible = False
        End If
    End Sub


    Private Function ItemNameExistsInDatabase(itemName As String) As Boolean
        Try
            ' Define your SQL query to check if item name exists in the database
            Dim query As String = "SELECT COUNT(*) FROM ItemDetail WHERE ItemName LIKE @ItemName"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter value for the item name
                    command.Parameters.AddWithValue("@ItemName", itemName + "%") ' Add % wildcard to match names starting with the entered text

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command and retrieve the count of matching item names
                    Dim count As Integer = CInt(command.ExecuteScalar())

                    ' Return true if at least one similar item name exists in the database
                    Return count > 0
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error checking item name in database: " & ex.Message)
            Return False ' Return false in case of any exception
        End Try
    End Function
    Private Sub Client_id_TextChanged(sender As Object, e As EventArgs) Handles Client_id.TextChanged

    End Sub
    Private Sub LoadItemNames(searchText As String)
        Try
            ' Define your SQL query to select item details based on the entered text
            Dim query As String = "SELECT ID.ItemDetail_id, ID.ItemName, ID.Batch, ID.Godown, ID.Pakage, ID.Unit, ID.Opening_Stock, ID.Closing_Stock, ID.MRP, ID.GST " &
                              "FROM ItemDetail ID " &
                              "INNER JOIN ItemMaster IM ON ID.master_id = IM.master_id " &
                              "WHERE Closing_Stock > 0 and ID.ItemName LIKE @SearchText + '%'"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter value for the search text
                    command.Parameters.AddWithValue("@SearchText", searchText)

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command and retrieve the item details
                    Using reader As SqlDataReader = command.ExecuteReader()
                        ' Clear the ListBox items
                        ListBox2.Items.Clear()

                        ' Loop through the results and add them to the ListBox
                        While reader.Read()
                            ' Concatenate item details including ItemDetail_id and add them to the ListBox
                            Dim itemDetails As String = $"{reader("ItemName")} :  {reader("ItemDetail_id")} :  {reader("Batch")} :  {reader("Godown")} :  {reader("Pakage")} :  {reader("Unit")} : Stock- {reader("Closing_Stock")} : MRP-{reader("MRP")} : {reader("GST")}"


                            ListBox2.Items.Add(itemDetails)

                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading item details: " & ex.Message)
        End Try

    End Sub


    Private Sub AutofillItemData()
        ' Check if an item is selected in ListBox2
        If ListBox2.SelectedIndex <> -1 Then
            ' Get the selected item from ListBox2
            Dim selectedItem As String = ListBox2.SelectedItem.ToString()

            ' Split the selected item to extract the ItemName and ItemDetail_id
            Dim itemDetails() As String = selectedItem.Split(":"c)

            ' Autofill the ItemName textbox with the extracted ItemName
            If itemDetails.Length > 0 Then
                ' Trim to remove leading and trailing spaces
                Itemname.Text = itemDetails(0).Trim()

                ' If ItemDetail_id is present in the itemDetails array
                If itemDetails.Length > 1 Then
                    ' Trim to remove leading and trailing spaces and set the value in Client_id textbox
                    Client_id.Text = itemDetails(1).Trim()

                End If
            End If

            ' Hide ListBox2 after autofilling
            ListBox2.Visible = False

            ' Set focus to the Qty textbox

        End If
    End Sub



    Private Sub Itemname_KeyDown(sender As Object, e As KeyEventArgs) Handles Itemname.KeyDown
        If ListBox2.Visible = True Then
            If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
                ListBox2.Focus()
                e.SuppressKeyPress = True

            End If
        ElseIf ListBox1.Visible = False Then
            If e.KeyCode = Keys.Down Then
                qty.Focus()
                e.SuppressKeyPress = True
            End If
            If e.KeyCode = Keys.Enter Then
                qty.Focus()
                e.SuppressKeyPress = True

            End If
        End If
    End Sub

    Private Sub ListBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox2.KeyDown
        If e.KeyCode = Keys.Enter Then
            If ListBox2.SelectedIndex <> -1 Then
                AutofillItemData()
                ListBox2.Visible = False
                qty.Focus()
                e.SuppressKeyPress = True
            End If
        ElseIf e.KeyCode = Keys.Down Then
            If ListBox2.SelectedIndex = ListBox2.Items.Count - 1 Then
                e.SuppressKeyPress = True
                Return ' Do not move selection further down
            End If
        ElseIf e.KeyCode = Keys.Up Then
            If ListBox2.SelectedIndex = 0 Then
                e.SuppressKeyPress = True
                Itemname.Focus()
            End If
        End If
    End Sub


    ' Add event handlers for other controls as needed
    Private Sub ListBox2_DoubleClick(sender As Object, e As EventArgs) Handles ListBox2.DoubleClick
        AutofillItemData()
    End Sub

    Private Sub Billno_TextChanged(sender As Object, e As EventArgs) Handles Billno.TextChanged
        ' Check if the length of entered text is greater than 3
        If Billno.Text.Length > 3 Then
            ' If the length exceeds 3, trim the text to 3 characters
            Billno.Text = Billno.Text.Substring(0, 3)
            ' Set the selection to the end of the text
            Billno.SelectionStart = Billno.TextLength
        End If

        ' Validate if the entered text contains non-numeric characters
        Dim newText As String = ""
        For Each c As Char In Billno.Text
            If Char.IsDigit(c) Then
                newText &= c
            End If
        Next
        ' Update the text in the textbox to remove non-numeric characters
        Billno.Text = newText
        ' Set the selection to the end of the text
        Billno.SelectionStart = Billno.TextLength
    End Sub



    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
        ' Call the method to clear textboxes, hide list boxes, and clear DataGridView
        ClearForm()
    End Sub

    Private Sub ClearForm()
        ' Clear all textboxes
        cust.Text = ""
        address.Text = ""
        Mobile_number.Text = ""
        Itemname.Text = ""
        qty.Text = ""
        Price.Text = ""
        Discount.Text = ""
        TotalAmt.Text = ""
        NetbillAmt.Text = ""
        GSTAmt.Text = ""

        cust.Focus()
        ' Hide both ListBox1 and ListBox2
        ListBox1.Visible = False
        ListBox2.Visible = False

        ' Clear the DataGridView
        DataGridView1.Rows.Clear()

        ' Uncheck the notGST checkbox
        notGST.Checked = False

        ' Clear DataGridView and recalculate column totals
        CalculateColumnTotals()

        ' Reset invalid cell variables
        invalidCellRow = -1
        invalidCellColumn = -1

        ' Enable save and modify buttons
        Save.Enabled = True
        Modify.Enabled = True

        ' Fetch and display the maximum bill number from the SalesInvoiceMaster table
        SetNextBillNumber()
        ListBox3.Visible = False
        CalculateColumnTotals()
    End Sub

    Private Sub ClearForm2()
        ' Clear all textboxes

        Itemname.Text = ""
        qty.Text = ""
        Price.Text = ""
        Discount.Text = ""
        TotalAmt.Text = ""
        NetbillAmt.Text = ""
        GSTAmt.Text = ""
        DisAmt.Text = ""


        ' Hide both ListBox1 and ListBox2
        ListBox1.Visible = False
        ListBox2.Visible = False

        ' Clear the DataGridView
        CalculateColumnTotals()

        ' Uncheck the notGST checkbox
        notGST.Checked = False
    End Sub
    Private Sub ClearForm3()

        Itemname.Text = ""
        qty.Text = ""
        Price.Text = ""
        Discount.Text = ""



    End Sub
    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
        Me.Dispose()
    End Sub



    Private Sub FillDataGridView()
        ' Check if Itemname, Qty, Price, and Discount are not empty
        If Not String.IsNullOrWhiteSpace(Itemname.Text) AndAlso
        Not String.IsNullOrWhiteSpace(qty.Text) AndAlso
        Not String.IsNullOrWhiteSpace(Price.Text) Then

            Try
                ' Fetch data based on Itemname
                Dim itemId As Integer
                Dim itemDetails As String = ListBox2.SelectedItem.ToString()
                Dim itemDetailParts() As String = itemDetails.Split(":"c)
                If itemDetailParts.Length > 1 Then
                    itemId = Convert.ToInt32(itemDetailParts(1).Trim())
                Else
                    ' If Item ID not found, move focus to the next column in the DataGridView
                    MoveFocusToNextColumn()
                    MessageBox.Show("Error: Item ID not found.")
                    Return
                End If

                ' Check if the itemId already exists in DataGridView1
                For Each row As DataGridViewRow In DataGridView1.Rows
                    If row.Cells("ItemID").Value = Client_id.Text Then
                        MessageBox.Show("Dublicate Item")
                        ClearForm3()
                        Return
                    End If
                Next

                ' Query to fetch data for DataGridView1
                Dim query As String = "SELECT ID.ItemDetail_id, ID.ItemName, M.Mfrname, ITM.Itemtype, ID.Batch, ID.Godown " &
                "FROM ItemDetail ID " &
                "INNER JOIN Itemmaster IM ON ID.master_id = IM.master_id " &
                "INNER JOIN MfrMaster M ON IM.mfr_id = M.mfr_Id " &
                "INNER JOIN ItemtypeMaster ITM ON IM.item_id = ITM.item_id " &
                "WHERE ID.ItemDetail_id = @ItemId"

                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand(query, connection)
                        command.Parameters.AddWithValue("@ItemId", itemId)
                        connection.Open()

                        Using reader As SqlDataReader = command.ExecuteReader()
                            If reader.Read() Then
                                ' Fetch item details
                                Dim itemName As String = If(reader.IsDBNull(1), "Null", reader("ItemName").ToString())
                                Dim mfrName As String = If(reader.IsDBNull(2), "Null", reader("Mfrname").ToString())
                                Dim itemType As String = If(reader.IsDBNull(3), "Null", reader("Itemtype").ToString())
                                Dim batch As String = If(reader.IsDBNull(4), "Null", reader("Batch").ToString())
                                Dim godown As String = If(reader.IsDBNull(5), "Null", reader("Godown").ToString())

                                ' Calculate the amount
                                Dim qtyValue As Integer = Integer.Parse(qty.Text)
                                Dim priceValue As Double = Double.Parse(Price.Text)
                                Dim discountValue As Double = If(String.IsNullOrWhiteSpace(Discount.Text), 0, Double.Parse(Discount.Text))
                                Dim amount As Double = qtyValue * priceValue * (1 - discountValue / 100)

                                ' Calculate GST amount
                                Dim GST_per As Decimal = If(notGST.Checked, 0, 3)
                                Dim Amt As Decimal = qtyValue * priceValue
                                Dim DisAmt As Double = Amt - amount
                                Dim GSTAmount As Decimal = amount * (GST_per / 100)
                                Dim TotalAmt As Decimal = Amt + GSTAmount - (Amt - amount)
                                Dim SGST_per As Decimal = GST_per / 2
                                Dim SGSTAmount As Decimal = GSTAmount / 2
                                Dim CGST_per As Decimal = GST_per / 2
                                Dim CGSTAmount As Decimal = GSTAmount / 2
                                Dim Delete As String = "X"

                                ' Add data to DataGridView1 with formatted values
                                Dim discount1Value As String = If(String.IsNullOrWhiteSpace(Discount.Text), "0", Discount.Text)
                                ' Check if discount is within valid range
                                If discountValue > 100 Then
                                    MoveFocusToNextColumn()
                                    MessageBox.Show("Discount cannot be greater than 100%.")
                                    Return
                                End If

                                Dim rowIndex As Integer = DataGridView1.Rows.Add(
                                itemId.ToString(), ' ItemDetail_id
                                "", ' Leave the first column empty for auto-incrementing serial number
                                itemName, ' ItemName
                                mfrName, ' Mfrname
                                itemType, ' Itemtype
                                batch, ' Batch
                                godown, ' Godown
                                qty.Text, ' Qty
                                Price.Text, ' Price
                                discount1Value, ' Discount1, set to 0 if Discount.Text is empty
                                DisAmt.ToString("N2"), ' Amount
                                GST_per.ToString(), ' GST_per
                                GSTAmount.ToString("N2"), ' GSTAmount
                                Amt.ToString("N2"), ' Calculate and display the amount
                                TotalAmt.ToString("N2"),
                                SGST_per.ToString("N1"),
                                SGSTAmount.ToString("N2"),
                                CGST_per.ToString("N1"),
                                CGSTAmount.ToString("N2"),
                                Delete
                            )

                                ' If a row was added, set the serial number (sr_no) in the first column
                                If rowIndex >= 0 Then
                                    DataGridView1.Rows(rowIndex).Cells(1).Value = (rowIndex + 1).ToString()
                                End If

                                CalculateTotalAmount()
                                ClearForm2()
                            End If
                        End Using
                    End Using
                End Using

            Catch ex As Exception
                MoveFocusToNextColumn()
                MessageBox.Show("Error : " & ex.Message)
            End Try

        Else
            ' If any required field is empty, move focus to the next column in the DataGridView
            MoveFocusToNextColumn()
        End If

        CalculateColumnTotals()
    End Sub

    Private Sub MoveFocusToNextColumn()
        ' Get the current cell
        Dim currentCell As DataGridViewCell = DataGridView1.CurrentCell

        ' If current cell exists and it's not in the last column, move focus to the next column
        If currentCell IsNot Nothing AndAlso currentCell.ColumnIndex < DataGridView1.Columns.Count - 1 Then
            Dim nextCell As DataGridViewCell = DataGridView1.Rows(currentCell.RowIndex).Cells(currentCell.ColumnIndex + 1)
            If nextCell.Visible Then
                DataGridView1.CurrentCell = nextCell
            End If
        ElseIf currentCell IsNot Nothing AndAlso currentCell.RowIndex < DataGridView1.Rows.Count - 1 Then
            ' If current cell is in the last column, move focus to the first column of the next row
            Dim nextRow As DataGridViewRow = DataGridView1.Rows(currentCell.RowIndex + 1)
            If nextRow.Visible Then
                DataGridView1.CurrentCell = nextRow.Cells(1)
            End If
        End If
    End Sub



    Private Sub CalculateColumnTotals()
        ' Calculate totals for each column
        Dim columnCount As Integer = DataGridView1.Columns.Count
        Dim rowCount As Integer = DataGridView1.Rows.Count

        ' Make sure there are rows in the DataGridView
        If rowCount > 0 Then
            Dim totals(columnCount - 1) As Double

            ' Iterate through each row
            For rowIndex As Integer = 0 To rowCount - 2 ' Exclude the last row which is for totals
                Dim row As DataGridViewRow = DataGridView1.Rows(rowIndex)

                ' Make sure the row is not a new row
                If Not row.IsNewRow Then
                    ' Iterate through each cell in the row
                    For columnIndex As Integer = 0 To columnCount - 1
                        ' Skip columns that should not be included in the total calculation
                        If columnIndex <> 11 AndAlso columnIndex <> 15 AndAlso columnIndex <> 17 AndAlso columnIndex <> 9 AndAlso columnIndex <> 5 Then
                            ' Make sure the cell value is not null and is numeric
                            If row.Cells(columnIndex).Value IsNot Nothing AndAlso IsNumeric(row.Cells(columnIndex).Value) Then
                                totals(columnIndex) += Convert.ToDouble(row.Cells(columnIndex).Value)
                            End If
                        End If
                    Next
                End If
            Next

            ' Set the values of the total row
            Dim totalRow As DataGridViewRow = DataGridView1.Rows(rowCount - 1) ' Get the last row
            For i As Integer = 0 To columnCount - 1
                If i = 1 Then
                    ' Set "Total" in the "Sr no" column
                    totalRow.Cells(i).Value = "Total"
                Else
                    ' Set the total value for other columns
                    If i = DataGridView1.Columns("qtty").Index Then
                        ' For Quantity column, no decimal places
                        totalRow.Cells(i).Value = totals(i).ToString() ' No decimal places
                    ElseIf totals(i) <> 0 OrElse i = DataGridView1.Columns("DiscountAmount").Index Then
                        ' For other columns, format to 2 decimal places
                        totalRow.Cells(i).Value = totals(i).ToString("N2") ' Format to 2 decimal places
                    Else
                        ' If total is zero and it's not the DiscountAmount column, set the cell value to blank
                        totalRow.Cells(i).Value = ""
                    End If
                End If
                ' Format the cell to display values in red with bold font
                totalRow.Cells(i).Style.ForeColor = Color.Red
                ' Make the cell read-only
                totalRow.Cells(i).ReadOnly = True
            Next
        End If
    End Sub



    Private Sub UpdateRowCalculations(rowIndex As Integer)
        If rowIndex >= 0 AndAlso rowIndex < DataGridView1.Rows.Count Then
            Dim row As DataGridViewRow = DataGridView1.Rows(rowIndex)
            Dim qtyValue As Integer
            Dim priceValue As Double
            Dim originalDiscountValue As Double ' Store the original discount percentage
            Dim discountAmountValue As Double

            If Integer.TryParse(row.Cells("qtty").Value?.ToString(), qtyValue) AndAlso
           Double.TryParse(row.Cells("price1").Value?.ToString(), priceValue) AndAlso
           Double.TryParse(row.Cells("DiscountAmount").Value?.ToString(), discountAmountValue) AndAlso
           Double.TryParse(row.Cells("discount1").Value?.ToString(), originalDiscountValue) Then

                ' Calculate the amount based on the original discount percentage


                ' Update the DataGridView cells with formatted values
                Dim amount As Double = qtyValue * priceValue * (1 - originalDiscountValue / 100)
                Dim GST_per As Decimal = If(notGST.Checked, 0, 3)
                Dim Amt As Decimal = qtyValue * priceValue
                Dim GSTAmount As Decimal = (qtyValue * priceValue) * (GST_per / 100)

                Dim SGST_per As Decimal = GST_per / 2
                Dim SGSTAmount As Decimal = GSTAmount / 2
                Dim CGST_per As Decimal = GST_per / 2
                Dim CGSTAmount As Decimal = GSTAmount / 2
                Dim DisAmt As Double = Amt - amount
                Dim TotalAmt As Decimal = Amt + GSTAmount - DisAmt

                row.Cells(10).Value = DisAmt.ToString("N2") ' Format to 2 decimal points
                row.Cells(11).Value = GST_per.ToString("N1") ' No formatting needed
                row.Cells(12).Value = GSTAmount.ToString("N2") ' Format to 2 decimal points
                row.Cells(13).Value = Amt.ToString("N2") ' Format to 2 decimal points
                row.Cells(14).Value = TotalAmt.ToString("N2") ' Format to 2 decimal points
                row.Cells(15).Value = SGST_per.ToString("N1") ' No formatting needed
                row.Cells(16).Value = SGSTAmount.ToString("N2") ' Format to 2 decimal points
                row.Cells(17).Value = CGST_per.ToString("N1") ' No formatting needed
                row.Cells(18).Value = CGSTAmount.ToString("N2") ' Format to 2 decimal points

                ' Update the calculated values for GSTAmt, NetbillAmt, and DisAmt
                UpdateCalculatedValues()

                ' Update the total amount

            End If
        End If
    End Sub



    Private Sub UpdateCalculatedValues()
        ' Update the GSTAmt TextBox with the total GSTAmount
        GSTAmt.Text = GetTotalGSTAmount().ToString() ' Format to 2 decimal points

        ' Update the NetbillAmt TextBox with the total Amount
        NetbillAmt.Text = GetTotalNetbillAmount().ToString() ' Format to 2 decimal points

        ' Update the DiscountAmt TextBox with the total DiscountAmount
        DisAmt.Text = GetTotalDiscountAmount().ToString() ' Format to 2 decimal points

        ' Update the TotalAmt TextBox with the total amount
        CalculateTotalAmount()
    End Sub






    Private Sub TotalAmt_TextChanged(sender As Object, e As EventArgs) Handles TotalAmt.TextChanged
        CalculateTotalAmount()
    End Sub

    Private Sub CalculateTotalAmount()
        Dim totalAmount As Decimal = 0

        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                Dim totalAmtCell As DataGridViewCell = row.Cells(14)
                ' Check if the font color is not red
                If totalAmtCell.Style.ForeColor <> Color.Red Then
                    If totalAmtCell.Value IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(totalAmtCell.Value.ToString()) Then
                        Dim rowTotalAmt As Decimal
                        If Decimal.TryParse(totalAmtCell.Value.ToString(), rowTotalAmt) Then
                            totalAmount += rowTotalAmt
                        End If
                    End If
                End If
            End If
        Next

        ' Display the total amount in the TotalAmt textbox
        TotalAmt.Text = totalAmount.ToString()
    End Sub

    Private Sub DataGridView1_CurrentCellDirtyStateChanged(sender As Object, e As EventArgs) Handles DataGridView1.CurrentCellDirtyStateChanged
        ' Check if the current cell is dirty (i.e., its value has changed)
        If DataGridView1.IsCurrentCellDirty Then
            ' Commit the change to trigger the CellValueChanged event
            DataGridView1.CommitEdit(DataGridViewDataErrorContexts.Commit)
        End If
    End Sub
    Private originalQttyValue As Integer ' Field to store the original value of "qtty" cell

    Private Sub DataGridView1_CellBeginEdit(sender As Object, e As DataGridViewCellCancelEventArgs) Handles DataGridView1.CellBeginEdit
        ' Store the original value of "qtty" cell before editing begins
        If e.RowIndex >= 0 AndAlso e.ColumnIndex = DataGridView1.Columns("qtty").Index Then
            Integer.TryParse(DataGridView1.Rows(e.RowIndex).Cells("qtty").Value?.ToString(), originalQttyValue)
        End If
    End Sub

    Private invalidCellRow As Integer
    Private invalidCellColumn As Integer
    Private currentCellRow As Integer
    Private currentCellColumn As Integer

    Private Sub DataGridView1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged
        ' Store the current cell before the value changes
        currentCellRow = e.RowIndex
        currentCellColumn = e.ColumnIndex

        ' Check if the DataGridView contains any rows
        If DataGridView1.Rows.Count > 0 Then
            ' Check if the changed cell is in the discount, qty, price, or DiscountAmount columns
            If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 AndAlso e.RowIndex < DataGridView1.Rows.Count AndAlso e.ColumnIndex < DataGridView1.Columns.Count Then
                If e.ColumnIndex = DataGridView1.Columns("qtty").Index OrElse
               e.ColumnIndex = DataGridView1.Columns("price1").Index OrElse
               e.ColumnIndex = DataGridView1.Columns("discount1").Index OrElse
               e.ColumnIndex = DataGridView1.Columns("DiscountAmount").Index Then
                    UpdateRowCalculations(e.RowIndex)

                    ' Recalculate the column totals
                    CalculateColumnTotals()
                    UpdateCalculatedValues()

                    ' Validate price and quantity cells
                    If DataGridView1.Rows.Count > 1 Then
                        If e.ColumnIndex = DataGridView1.Columns("qtty").Index Then
                            ValidateQuantityCell(e.RowIndex, e.ColumnIndex)
                        ElseIf e.ColumnIndex = DataGridView1.Columns("price1").Index Then
                            ValidatePriceCell(e.RowIndex, e.ColumnIndex)
                        End If

                        ' If the changed column is the discount column, validate the discount value
                        If e.ColumnIndex = DataGridView1.Columns("discount1").Index Then
                            Dim discountValue As Double
                            If Double.TryParse(DataGridView1.Rows(e.RowIndex).Cells("discount1").Value?.ToString(), discountValue) Then
                                ' Check if discount exceeds 100%
                                If discountValue > 100 Then
                                    MessageBox.Show("Discount cannot be greater than 100%.")
                                    DataGridView1.Rows(e.RowIndex).Cells("discount1").Value = "100"
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If


    End Sub
    'Private Sub DataGridView1_CellValueChanged(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellValueChanged
    '    ' Store the current cell before the value changes
    '    currentCellRow = e.RowIndex
    '    currentCellColumn = e.ColumnIndex

    '    ' Check if the changed cell is in the discount, qty, price, or DiscountAmount columns
    '    If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 AndAlso e.RowIndex < DataGridView1.Rows.Count AndAlso e.ColumnIndex < DataGridView1.Columns.Count Then
    '        If e.ColumnIndex = DataGridView1.Columns("qtty").Index OrElse
    '       e.ColumnIndex = DataGridView1.Columns("price1").Index OrElse
    '       e.ColumnIndex = DataGridView1.Columns("discount1").Index OrElse
    '       e.ColumnIndex = DataGridView1.Columns("DiscountAmount").Index Then

    '            ' Update calculations for the affected row
    '            UpdateRowCalculations(e.RowIndex)

    '            ' Recalculate the column totals
    '            CalculateColumnTotals()
    '            UpdateCalculatedValues()

    '            ' Validate price and quantity cells
    '            If DataGridView1.Rows.Count > 1 Then
    '                If e.ColumnIndex = DataGridView1.Columns("qtty").Index Then
    '                    ValidateQuantityCell(e.RowIndex, e.ColumnIndex)

    '                    ' Check stock availability if quantity changes
    '                    If CheckStockAvailability(e.RowIndex) = False Then
    '                        ' Restore the previous value of quantity if stock is not available
    '                        Dim previousValue As Object = DataGridView1.Rows(e.RowIndex).Cells("qtty").Tag
    '                        DataGridView1.Rows(e.RowIndex).Cells("qtty").Value = previousValue
    '                    End If
    '                ElseIf e.ColumnIndex = DataGridView1.Columns("price1").Index Then
    '                    ValidatePriceCell(e.RowIndex, e.ColumnIndex)
    '                End If

    '                ' If the changed column is the discount column, validate the discount value
    '                If e.ColumnIndex = DataGridView1.Columns("discount1").Index Then
    '                    Dim discountValue As Double
    '                    If Double.TryParse(DataGridView1.Rows(e.RowIndex).Cells("discount1").Value?.ToString(), discountValue) Then
    '                        ' Check if discount exceeds 100%
    '                        If discountValue > 100 Then
    '                            MessageBox.Show("Discount cannot be greater than 100%.")
    '                            DataGridView1.Rows(e.RowIndex).Cells("discount1").Value = "100"
    '                        End If
    '                    End If
    '                End If
    '            End If
    '        End If
    '    End If
    'End Sub
    'Private Function CheckStockAvailability(rowIndex As Integer) As Boolean
    '    Try
    '        Dim itemID As String = DataGridView1.Rows(rowIndex).Cells("ItemID").Value.ToString()
    '        Dim qty As Integer = Integer.Parse(DataGridView1.Rows(rowIndex).Cells("qtty").Value.ToString()) ' Convert to int

    '        ' Fetch the current Closing_Stock from the database
    '        Dim currentClosingStock As Integer
    '        Using connection As New SqlConnection(connectionString)
    '            Using command As New SqlCommand("SELECT Closing_Stock FROM ItemDetail WHERE ItemDetail_id = @ItemID;", connection)
    '                command.Parameters.AddWithValue("@ItemID", itemID)
    '                connection.Open()
    '                Dim result = command.ExecuteScalar()
    '                If result IsNot Nothing Then
    '                    If Integer.TryParse(result.ToString(), currentClosingStock) Then
    '                        ' Successfully parsed Closing_Stock to an integer
    '                    Else
    '                        MessageBox.Show("Error: Closing Stock contains non-numeric values for Item ID " & itemID)
    '                        Return False ' Return false if stock contains non-numeric values
    '                    End If
    '                Else
    '                    MessageBox.Show("Error: Closing Stock not found for Item ID " & itemID)
    '                    Return False ' Return false if stock not found
    '                End If
    '            End Using
    '        End Using

    '        ' Check if the entered quantity is greater than the closing stock
    '        If qty > currentClosingStock Then
    '            ' Display a message if the quantity exceeds the closing stock
    '            MessageBox.Show("Quantity exceeds available stock for Item ID " & itemID, "Stock Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning)
    '            Return False ' Indicate that stock is not available
    '        End If

    '        ' Store the current quantity value as tag for potential restoration
    '        DataGridView1.Rows(rowIndex).Cells("qtty").Tag = qty

    '        Return True ' Indicate that stock is available
    '    Catch ex As Exception
    '        MessageBox.Show("Error: " & ex.Message)
    '        Return False ' Return false in case of any exception
    '    End Try
    'End Function


    Private Sub ValidateQuantityCell(rowIndex As Integer, columnIndex As Integer)
        Dim cellValue As Double
        If Not Double.TryParse(DataGridView1.Rows(rowIndex).Cells(columnIndex).Value?.ToString(), cellValue) OrElse cellValue <= 0 Then
            MessageBox.Show("Please enter a quantity greater than 0.")
            invalidCellRow = rowIndex
            invalidCellColumn = columnIndex
            DataGridView1.BeginInvoke(New Action(Sub() FocusInvalidCell()))
        End If
    End Sub

    Private Sub ValidatePriceCell(rowIndex As Integer, columnIndex As Integer)
        Dim cellValue As Double
        If Not Double.TryParse(DataGridView1.Rows(rowIndex).Cells(columnIndex).Value?.ToString(), cellValue) OrElse cellValue <= 0 Then
            MessageBox.Show("Please enter a Price greater than 0.")
            invalidCellRow = rowIndex
            invalidCellColumn = columnIndex
            DataGridView1.BeginInvoke(New Action(Sub() FocusInvalidCell()))
        End If
    End Sub

    Private Sub FocusInvalidCell()
        If invalidCellRow >= 0 AndAlso invalidCellColumn >= 0 Then
            DataGridView1.CurrentCell = DataGridView1.Rows(invalidCellRow).Cells(invalidCellColumn)
            DataGridView1.BeginEdit(True)
        ElseIf currentCellRow >= 0 AndAlso currentCellColumn >= 0 Then
            ' If no invalid cell, focus on the cell where the change occurred before
            DataGridView1.CurrentCell = DataGridView1.Rows(currentCellRow).Cells(currentCellColumn)
            DataGridView1.BeginEdit(True)
        End If
    End Sub



    Private Sub DataGridView1_EditingControlShowing(sender As Object, e As DataGridViewEditingControlShowingEventArgs) Handles DataGridView1.EditingControlShowing
        ' Check if the editing control is a DataGridViewTextBoxEditingControl
        If TypeOf e.Control Is DataGridViewTextBoxEditingControl Then
            Dim textBox As DataGridViewTextBoxEditingControl = DirectCast(e.Control, DataGridViewTextBoxEditingControl)

            ' Remove any existing event handler to avoid adding multiple handlers
            RemoveHandler textBox.KeyPress, AddressOf TextBox_KeyPress

            ' Attach event handler to the editing control's KeyPress event
            AddHandler textBox.KeyPress, AddressOf TextBox_KeyPress
        End If
    End Sub

    Private Sub TextBox_KeyPress(sender As Object, e As KeyPressEventArgs)
        ' Check if the pressed key is a digit (0 to 9), backspace, or decimal point
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "." Then
            ' Ignore the input if it's not a valid numeric character
            e.Handled = True
        End If
    End Sub

    Private Sub DataGridView1_CellValidating(sender As Object, e As DataGridViewCellValidatingEventArgs) Handles DataGridView1.CellValidating
        ' Check if the edited cell is in the discount, qty, price, or DiscountAmount columns
        If e.RowIndex >= 0 AndAlso e.ColumnIndex >= 0 AndAlso e.RowIndex < DataGridView1.Rows.Count AndAlso e.ColumnIndex < DataGridView1.Columns.Count Then
            If e.ColumnIndex = DataGridView1.Columns("qtty").Index OrElse
           e.ColumnIndex = DataGridView1.Columns("price1").Index OrElse
           e.ColumnIndex = DataGridView1.Columns("discount1").Index OrElse
           e.ColumnIndex = DataGridView1.Columns("DiscountAmount").Index Then

                Dim cell As DataGridViewTextBoxCell = TryCast(DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex), DataGridViewTextBoxCell)
                If cell IsNot Nothing Then
                    Dim newValue As String = e.FormattedValue.ToString()

                    ' Convert the value to a double and round off to two decimal places
                    Dim roundedValue As Double
                    If Double.TryParse(newValue, roundedValue) Then
                        roundedValue = Math.Round(roundedValue, 2)
                        DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value = roundedValue.ToString()
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub DataGridView1_KeyDown(sender As Object, e As KeyEventArgs) Handles DataGridView1.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Check if an item is selected in ListBox2
            If ListBox2.SelectedItem IsNot Nothing Then
                ' Call a method to fill the DataGridView1
                FillDataGridView()
            Else
                MessageBox.Show("Please select an item from the list.")
            End If

            ' Prevent the default behavior of the Enter key
            e.Handled = True
        ElseIf e.KeyCode = Keys.Up Then
            ' Navigate to the previous row in the DataGridView
            If DataGridView1.SelectedCells.Count > 0 Then
                Dim currentRowIndex As Integer = DataGridView1.SelectedCells(0).RowIndex
                If currentRowIndex > 0 Then
                    DataGridView1.Rows(currentRowIndex - 1).Cells(1).Selected = True
                End If
            End If
        ElseIf e.KeyCode = Keys.Down Then
            ' Navigate to the next row in the DataGridView
            If DataGridView1.SelectedCells.Count > 0 Then
                Dim currentRowIndex As Integer = DataGridView1.SelectedCells(0).RowIndex
                If currentRowIndex < DataGridView1.Rows.Count - 1 Then
                    DataGridView1.Rows(currentRowIndex + 1).Cells(1).Selected = True
                End If
            End If
        ElseIf e.KeyCode = Keys.Enter Then
            ' Move focus to the next column in the DataGridView
            Dim currentCell As DataGridViewCell = DataGridView1.CurrentCell
            If currentCell IsNot Nothing AndAlso currentCell.ColumnIndex < DataGridView1.Columns.Count - 1 Then
                DataGridView1.CurrentCell = DataGridView1.Rows(currentCell.RowIndex).Cells(currentCell.ColumnIndex + 1)
            End If
        End If
    End Sub      ' Move focus to the next column in the DataGridView

    Private Sub DataGridView1_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellClick
        ' Check if the clicked cell is in the last column and the clicked content is "X"
        If e.ColumnIndex = DataGridView1.Columns.Count - 1 AndAlso e.RowIndex >= 0 AndAlso
        TypeOf DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value Is String AndAlso
        DirectCast(DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value, String) = "X" Then

            ' Remove the row from the DataGridView
            DataGridView1.Rows.RemoveAt(e.RowIndex)
            CalculateColumnTotals()

            ' Update serial numbers
            UpdateSerialNumbers()
        End If
    End Sub
    Private Sub UpdateSerialNumbers()
        ' Iterate through the rows and update the serial numbers
        For i As Integer = 0 To DataGridView1.Rows.Count - 1
            ' Check if the current row is the last row
            If i = DataGridView1.Rows.Count - 1 Then
                ' Replace the serial number with "Total"
                DataGridView1.Rows(i).Cells(0).Value = "Total"
            Else
                ' For other rows, assign serial number if the row is not empty
                If Not DataGridView1.Rows(i).IsNewRow Then
                    DataGridView1.Rows(i).Cells(0).Value = (i + 1).ToString()
                End If
            End If
        Next i
    End Sub


    Private Sub DataGridView1_CellFormatting(sender As Object, e As DataGridViewCellFormattingEventArgs) Handles DataGridView1.CellFormatting
        ' Check if the current cell is in the last column and the content is "X"
        If e.ColumnIndex = DataGridView1.Columns.Count - 1 AndAlso e.RowIndex >= 0 AndAlso
        TypeOf DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value Is String AndAlso
        DirectCast(DataGridView1.Rows(e.RowIndex).Cells(e.ColumnIndex).Value, String) = "X" Then

            ' Change the cell's foreground color to red
            e.CellStyle.ForeColor = Color.Red
        End If
    End Sub

    Private Sub qty_KeyPress(sender As Object, e As KeyPressEventArgs) Handles qty.KeyPress
        ' Allow only numeric characters, Backspace, and decimal separator (if not already present)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        ' Allow only one decimal separator
        If e.KeyChar = "."c AndAlso CType(sender, TextBox).Text.IndexOf(".") > -1 Then
            e.Handled = True
        End If
    End Sub

    Private Sub Price_Leave(sender As Object, e As EventArgs) Handles Price.Leave
        ' Check if the Price TextBox is not empty
        If Not String.IsNullOrWhiteSpace(Price.Text) Then
            ' Parse the Price value
            Dim priceValue As Double
            If Double.TryParse(Price.Text, priceValue) Then
                ' Round the Price value to two decimal points
                Price.Text = priceValue.ToString("N2")
            End If
        End If
    End Sub

    Private Sub Discount_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Discount.KeyPress
        ' Allow only numeric characters, Backspace, and decimal separator (if not already present)
        If Not Char.IsControl(e.KeyChar) AndAlso Not Char.IsDigit(e.KeyChar) AndAlso e.KeyChar <> "."c Then
            e.Handled = True
        End If

        ' Allow only one decimal separator
        If e.KeyChar = "."c AndAlso CType(sender, TextBox).Text.IndexOf(".") > -1 Then
            e.Handled = True
        End If
    End Sub


    Private Sub DateTimePicker1_KeyDown(sender As Object, e As KeyEventArgs) Handles DateTimePicker1.KeyDown
        If e.KeyCode = Keys.Enter OrElse e.KeyCode = Keys.Down Then
            Itemname.Focus()
        End If
    End Sub


    Private Sub Qty_KeyDown(sender As Object, e As KeyEventArgs) Handles qty.KeyDown
        If e.KeyCode = Keys.Enter Then
            Price.Focus()
        ElseIf e.KeyCode = Keys.Down Then
            Price.Focus()
        ElseIf e.KeyCode = Keys.Up Then
            Itemname.Focus()
        End If
    End Sub
    Private Sub cust_KeyDown(sender As Object, e As KeyEventArgs) Handles cust.KeyDown
        If e.KeyCode = Keys.Enter Then
            address.Focus()
        End If

    End Sub
    Private Sub Address_KeyDown(sender As Object, e As KeyEventArgs) Handles address.KeyDown
        If e.KeyCode = Keys.Enter Then
            Mobile_number.Focus()
        End If
    End Sub
    Private Sub Mobile_KeyDown(sender As Object, e As KeyEventArgs) Handles Mobile_number.KeyDown
        If e.KeyCode = Keys.Enter Then
            DateTimePicker1.Focus()
        End If
    End Sub
    Private Sub Price_KeyDown(sender As Object, e As KeyEventArgs) Handles Price.KeyDown
        If e.KeyCode = Keys.Enter Then
            Discount.Focus()
        ElseIf e.KeyCode = Keys.Down Then
            Discount.Focus()
        ElseIf e.KeyCode = Keys.Up Then
            qty.Focus()
        End If
    End Sub




    Private Sub Discount_KeyDown(sender As Object, e As KeyEventArgs) Handles Discount.KeyDown
        If e.KeyCode = Keys.Enter Then
            ' Check if an item is selected in ListBox2

            ' Validate Itemname
            If String.IsNullOrWhiteSpace(Itemname.Text) Then
                MessageBox.Show("Please enter an item name.")
                Itemname.Focus()
                Return
            End If

            ' Validate Price

            ' Validate Qty
            Dim qtyValue As Integer
            If Not Integer.TryParse(qty.Text, qtyValue) OrElse qtyValue <= 0 Then
                MessageBox.Show("Please enter a quantity greater than 0.")
                qty.Focus()
                Return
            End If

            Dim priceValue As Double
            If Not Double.TryParse(Price.Text, priceValue) OrElse priceValue <= 0 Then
                MessageBox.Show("Please enter a price greater than 0.")
                Price.Focus()
                Return
            End If

            ' Call a method to fill the DataGridView1
            FillDataGridView()
            Itemname.Focus()


        ElseIf e.KeyCode = Keys.Down Then
            ' Navigate to the next control
            DataGridView1.Focus()
        ElseIf e.KeyCode = Keys.Up Then
            Price.Focus()
        End If
    End Sub

    Private Function GetTotalGSTAmount() As Decimal
        Dim totalGSTAmount As Decimal = 0

        ' Iterate through all rows in the DataGridView and sum up the GSTAmount values
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim gstAmount As Decimal = 0
            Dim gstCell As DataGridViewCell = row.Cells(12)
            ' Check if the font color is not red
            If gstCell.Style.ForeColor <> Color.Red Then
                If Decimal.TryParse(gstCell.Value?.ToString(), gstAmount) Then
                    totalGSTAmount += gstAmount
                End If
            End If
        Next

        Return totalGSTAmount
    End Function

    Private Sub NetbillAmt_TextChanged(sender As Object, e As EventArgs) Handles NetbillAmt.TextChanged
        Dim totalAmount As Decimal = GetTotalNetbillAmount()
        ' Update the NetbillAmt TextBox with the total Amount
        NetbillAmt.Text = totalAmount.ToString() ' Format to 2 decimal points
    End Sub

    Private Function GetTotalNetbillAmount() As Decimal
        Dim totalAmount As Decimal = 0

        ' Iterate through all rows in the DataGridView and sum up the Amount values
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim amount As Decimal = 0
            Dim amountCell As DataGridViewCell = row.Cells(13)
            ' Check if the font color is not red
            If amountCell.Style.ForeColor <> Color.Red Then
                If Decimal.TryParse(amountCell.Value?.ToString(), amount) Then
                    totalAmount += amount
                End If
            End If
        Next

        Return totalAmount
    End Function

    Private Sub DisAmt_TextChanged(sender As Object, e As EventArgs) Handles DisAmt.TextChanged
        Dim totalDiscountAmount As Decimal = GetTotalDiscountAmount()
        ' Update the DiscountAmt TextBox with the total DiscountAmount
        DisAmt.Text = totalDiscountAmount.ToString() ' Format to 2 decimal points
    End Sub

    Private Function GetTotalDiscountAmount() As Decimal
        Dim totalDiscountAmount As Decimal = 0

        ' Iterate through all rows in the DataGridView and sum up the DiscountAmount values
        For Each row As DataGridViewRow In DataGridView1.Rows
            Dim discountAmount As Decimal = 0
            Dim discountCell As DataGridViewCell = row.Cells(10)
            ' Check if the font color is not red
            If discountCell.Style.ForeColor <> Color.Red Then
                If Decimal.TryParse(discountCell.Value?.ToString(), discountAmount) Then
                    totalDiscountAmount += discountAmount
                End If
            End If
        Next

        Return totalDiscountAmount
    End Function



    Private Sub notGST_CheckedChanged(sender As Object, e As EventArgs) Handles notGST.CheckedChanged
        Dim newGST_per As Decimal = If(notGST.Checked, 0, 3) ' Set GST_per to 0 if notGST is checked, otherwise set it to 3

        ' Iterate through each row in the DataGridView and update the GST_per column
        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then ' Skip the new row if present
                row.Cells(11).Value = newGST_per.ToString("N1") ' Update the GST_per column value
                ' Update other calculated values for the row
                UpdateRowCalculations(row.Index)
            End If
        Next

        ' Recalculate the column totals and update calculated values
        CalculateColumnTotals()
        UpdateCalculatedValues()
    End Sub
    Private Function IsPriceValid(price As String) As Boolean
        Dim priceValue As Double
        If Not Double.TryParse(price, priceValue) OrElse priceValue <= 0 Then
            Return False
        End If
        Return True
    End Function

    Private Function IsDiscountValid(discount As String) As Boolean
        Dim discountValue As Double
        If Not Double.TryParse(discount, discountValue) OrElse discountValue < 0 OrElse discountValue > 100 Then
            Return False
        End If
        Return True
    End Function
    Private Function IsQuantityValid(quantity As String) As Boolean
        Dim qtyValue As Double
        If Not Double.TryParse(quantity, qtyValue) OrElse qtyValue <= 0 Then
            Return False
        End If
        Return True
    End Function

    Private Sub Save_Click(sender As Object, e As EventArgs) Handles Save.Click
        ' Check if the Cust name is empty
        If String.IsNullOrWhiteSpace(cust.Text) Then
            MessageBox.Show("Please enter a Cust name.")
            cust.Focus()
            Return
        End If

        ' Check if there are any rows in the DataGridView
        If DataGridView1.RowCount = 1 Then
            MessageBox.Show("No items present. Please add at least one item.")
            Return
        End If

        ' Validate each cell in the DataGridView
        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not IsQuantityValid(row.Cells("qtty").Value?.ToString()) Then
                MessageBox.Show("Please enter a quantity greater than 0")
                DataGridView1.CurrentCell = row.Cells("qtty")
                DataGridView1.BeginEdit(True)
                Return
            End If

            If Not IsPriceValid(row.Cells("price1").Value?.ToString()) Then
                MessageBox.Show("Please enter a Price greater than 0")
                DataGridView1.CurrentCell = row.Cells("price1")
                DataGridView1.BeginEdit(True)
                Return
            End If

            If Not IsDiscountValid(row.Cells("discount1").Value?.ToString()) Then
                MessageBox.Show("Discount must be between 0 and 100.")
                DataGridView1.CurrentCell = row.Cells("discount1")
                DataGridView1.BeginEdit(True)
                Return
            End If
        Next

        ' Call the function to save data
        SaveData()

        ' Display success message
        MessageBox.Show("SalesInvoice saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub

    Private Function CheckStockAvailability() As Boolean
        Try
            Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"
            Dim stockAvailable As Boolean = True

            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim itemID As String = row.Cells("ItemID").Value.ToString()

                ' Fetch the current Closing_Stock from the database
                Dim currentClosingStock As Integer
                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand("SELECT Closing_Stock FROM ItemDetail WHERE ItemDetail_id = @ItemID;", connection)
                        command.Parameters.AddWithValue("@ItemID", itemID)
                        connection.Open()
                        Dim result = command.ExecuteScalar()
                        If result IsNot Nothing Then
                            currentClosingStock = Convert.ToInt32(result)
                        Else
                            MessageBox.Show("Error: Closing Stock not found for Item ID " & itemID)
                            Return False ' Return false if stock not found
                        End If
                    End Using
                End Using

                Dim qty As Integer = Integer.Parse(row.Cells("qtty").Value.ToString()) ' Convert to int

                ' Calculate new Closing_Stock
                Dim newClosingStock As Integer = currentClosingStock - qty

                ' Check if the new stock quantity is negative or zero
                If newClosingStock < 0 Then
                    ' Display a message if stock is low
                    MessageBox.Show("Stock is low. Stock available - " & currentClosingStock, "Stock Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    stockAvailable = False ' Set stockAvailable to false
                    Exit For ' Exit the loop if stock is low for any item
                End If
            Next

            Return stockAvailable ' Return the overall stock availability status

        Catch ex As Exception
            MessageBox.Show("Error: " & ex.Message)
            Return False ' Return false in case of any exception
        End Try
    End Function


    Private Sub SaveData()
        ' Extract necessary data from form controls
        Dim clientID As String = Client_id.Text
        Dim customerName As String = cust.Text
        Dim Address1 As String = address.Text
        Dim Itemtype1 As String = itemtype.Text
        Dim mobileNumber As String = Mobile_number.Text
        Dim billDate As String = DateTimePicker1.Value.ToString("yyyy-MM-dd")
        Dim totalFinalAmt As String = TotalAmt.Text
        Dim netBillAmt1 As String = NetbillAmt.Text
        Dim totalGstAmt As String = GSTAmt.Text
        Dim totalDisAmt As String = DisAmt.Text
        Dim billNo1 As String = Billno.Text ' Assuming Billno.Text is the bill number you want to store

        ' Define the connection string
        Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

        ' Insert data into the SalesInvoiceMaster table
        Dim insertQuery As String = "INSERT INTO SalesInvoiceMaster (Bill_no, Customer_ID, Customer_name, Address, Mobile_ni, Itemtype, Bill_date, TotalFinalAmt, NetBillAmt, Total_GstAmt, Total_DisAmt) " &
                         "VALUES (@Bill_no, @Customer_ID, @Customer_name, @Address, @Mobile_ni, @Itemtype, @Bill_date, @TotalFinalAmt, @NetBillAmt, @Total_GstAmt, @Total_DisAmt);"

        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(insertQuery, connection)
                ' Add parameters
                command.Parameters.AddWithValue("@Bill_no", billNo1)
                command.Parameters.AddWithValue("@Customer_ID", clientID)
                command.Parameters.AddWithValue("@Customer_name", customerName)
                command.Parameters.AddWithValue("@Address", Address1)
                command.Parameters.AddWithValue("@Mobile_ni", mobileNumber)
                command.Parameters.AddWithValue("@Itemtype", Itemtype1) ' Placeholder for itemtype, we'll set it later
                command.Parameters.AddWithValue("@Bill_date", billDate)
                command.Parameters.AddWithValue("@TotalFinalAmt", totalFinalAmt)
                command.Parameters.AddWithValue("@NetBillAmt", netBillAmt1)
                command.Parameters.AddWithValue("@Total_GstAmt", totalGstAmt)
                command.Parameters.AddWithValue("@Total_DisAmt", totalDisAmt)

                ' Open connection and execute query
                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using

        ' Insert data into the SalesInvoiceDetails table
        InsertSalesInvoiceDetails(connectionString, clientID)
    End Sub

    Private Sub InsertSalesInvoiceDetails(connectionString As String, clientID As String)
        Try
            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim srNo As String = row.Cells("Sr_no").Value.ToString()

                ' Skip rows where the Sr_no is "Total"
                If srNo.Trim().ToUpper() = "TOTAL" Then
                    Continue For
                End If

                ' Fetch the item type from the current row
                Dim itemtype As String = row.Cells(4).Value.ToString()

                ' Retrieve values for various columns from DataGridView cells
                Dim itemName As String = row.Cells(2).Value.ToString()
                Dim manufacturer As String = row.Cells(3).Value.ToString()
                Dim batch As String = row.Cells(5).Value.ToString()
                Dim godown As String = row.Cells(6).Value.ToString()
                Dim qty As String = row.Cells(7).Value.ToString()
                Dim price As String = row.Cells(8).Value.ToString()
                Dim disPercent As String = row.Cells(9).Value.ToString()
                Dim disAmt As String = row.Cells(10).Value.ToString()
                Dim gstPercent As String = row.Cells(11).Value.ToString()
                Dim gstamt As String = row.Cells(12).Value.ToString()
                Dim amount As String = row.Cells(13).Value.ToString()
                Dim totalAmt As String = row.Cells(14).Value.ToString()
                Dim sgstPer As String = row.Cells(15).Value.ToString()
                Dim sgstAmt As String = row.Cells(16).Value.ToString()
                Dim cgstPer As String = row.Cells(17).Value.ToString()
                Dim cgstAmt As String = row.Cells(18).Value.ToString()

                ' Define the SQL query to insert data into the SalesInvoiceDetails table
                Dim insertDetailQuery As String = "INSERT INTO SalesInvoiceDetails (Bill_no, Bill_date, Item_ID, Item_name, Manufature, ItemType, Batch, Godown, Qty, Price, Dis_Percent, Dis_Amt, GST_Per, GST_amt, Amount, Total_Amt, SGST_per, SGST_amt, CGST_per, CGST_amt) " &
                        "VALUES (@Bill_no, @Bill_date, @Item_ID, @Item_name, @Manufacturer, @ItemType, @Batch, @Godown, @Qty, @Price, @Dis_Percent, @Dis_Amt, @GST_Per, @GST_amt, @Amount, @Total_Amt, @SGST_per, @SGST_amt, @CGST_per, @CGST_amt);"

                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand(insertDetailQuery, connection)
                        ' Add parameters
                        command.Parameters.AddWithValue("@Bill_no", Billno.Text)
                        command.Parameters.AddWithValue("@Bill_date", DateTimePicker1.Value.ToString("yyyy-MM-dd"))
                        command.Parameters.AddWithValue("@Item_ID", clientID) ' Assuming Client_id is used as Item_ID
                        command.Parameters.AddWithValue("@Item_name", itemName)
                        command.Parameters.AddWithValue("@Manufacturer", manufacturer)
                        command.Parameters.AddWithValue("@ItemType", itemtype) ' Use the previously fetched itemtype
                        command.Parameters.AddWithValue("@Batch", batch)
                        command.Parameters.AddWithValue("@Godown", godown)
                        command.Parameters.AddWithValue("@Qty", qty)
                        command.Parameters.AddWithValue("@Price", price)
                        command.Parameters.AddWithValue("@Dis_Percent", disPercent)
                        command.Parameters.AddWithValue("@Dis_Amt", disAmt)
                        command.Parameters.AddWithValue("@GST_Per", gstPercent)
                        command.Parameters.AddWithValue("@GST_amt", gstamt)
                        command.Parameters.AddWithValue("@Amount", amount)
                        command.Parameters.AddWithValue("@Total_Amt", totalAmt)
                        command.Parameters.AddWithValue("@SGST_per", sgstPer)
                        command.Parameters.AddWithValue("@SGST_amt", sgstAmt)
                        command.Parameters.AddWithValue("@CGST_per", cgstPer)
                        command.Parameters.AddWithValue("@CGST_amt", cgstAmt)

                        ' Open connection and execute query
                        connection.Open()
                        command.ExecuteNonQuery()
                    End Using
                End Using
            Next
            UpdateStockQuantities()
            ClearForm()

        Catch ex As Exception
            MessageBox.Show("Add Items in Grid")
        End Try
    End Sub

    Private Sub UpdateStockQuantities()
        Try
            Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

            For Each row As DataGridViewRow In DataGridView1.Rows
                Dim itemID As String = row.Cells("ItemID").Value.ToString()

                ' Fetch the current Closing_Stock from the database
                Dim currentClosingStock As Integer
                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand("SELECT Closing_Stock FROM ItemDetail WHERE ItemDetail_id = @ItemID;", connection)
                        command.Parameters.AddWithValue("@ItemID", itemID)
                        connection.Open()
                        Dim result = command.ExecuteScalar()
                        If result IsNot Nothing Then
                            currentClosingStock = Convert.ToInt32(result)
                        Else
                            MessageBox.Show("Error: Closing Stock not found for Item ID " & itemID)
                            Continue For
                        End If
                    End Using
                End Using

                Dim qty As Integer = Integer.Parse(row.Cells("qtty").Value.ToString()) ' Convert to int

                ' Define the SQL query to update the stock quantities in the ItemDetail table
                Dim updateQuery As String = "UPDATE ItemDetail SET Closing_Stock = @NewClosingStock WHERE ItemDetail_id = @ItemID;"

                ' Calculate new Closing_Stock
                Dim newClosingStock As Integer = currentClosingStock - qty

                Using connection As New SqlConnection(connectionString)
                    Using command As New SqlCommand(updateQuery, connection)
                        ' Add parameters
                        command.Parameters.AddWithValue("@NewClosingStock", newClosingStock)
                        command.Parameters.AddWithValue("@ItemID", itemID)

                        ' Open connection and execute query
                        connection.Open()
                        command.ExecuteNonQuery()
                    End Using
                End Using
            Next

        Catch ex As Exception

        End Try
    End Sub


    Private Sub Modify_Click(sender As Object, e As EventArgs) Handles Modify.Click
        Save.Enabled = False

        ' Make ListBox3 visible
        If TotalAmt.Text = "0" Then
            ' Proceed with deletion
            ListBox3.Visible = True
            ListBox3.Visible = True

            ' Clear any previous items in ListBox3
            ListBox3.Items.Clear()
            ListBox3.Focus()
            ' Retrieve data from the salesInvoicemaster table and populate ListBox3
            Using connection As New SqlConnection("Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True")
                connection.Open()
                Dim query As String = "SELECT Bill_no, Bill_date, Customer_name, TotalFinalAmt FROM salesInvoicemaster"
                Using command As New SqlCommand(query, connection)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim billNo As String = reader("Bill_no").ToString()
                            Dim billDate As String = reader("Bill_date").ToString()
                            Dim customerName As String = reader("Customer_name").ToString()
                            Dim totalFinalAmt As String = reader("TotalFinalAmt").ToString()
                            ' Format the data into a single string and add it to ListBox3
                            Dim formattedString As String = $"{billNo}:{billDate}:{customerName}:{totalFinalAmt}"
                            ListBox3.Items.Add(formattedString)
                        End While
                    End Using
                End Using
            End Using
        Else
            ' Check if the current bill number exists in salesInvoicedetail and salesInvoicemaster
            Dim billExists As Boolean = CheckIfBillExists(Billno.Text)

            If billExists Then
                ' Call delete method here
                'InsertIntoTrashbin(Billno.Text)
                InsertIntoTrashbin(Billno.Text)

                ' Update stock from Trashbin
                UpdateStockFromTrashbin()

                'UpdateStockFromTrashbin()
                DeleteFromSalesInvoiceDetail(Billno.Text)
                DeleteFromSalesInvoiceMaster(Billno.Text)
            End If
            If String.IsNullOrWhiteSpace(cust.Text) Then
                MessageBox.Show("Please enter a Cust name.")
                cust.Focus()
                Return
            End If

            ' Check if there are any rows in the DataGridView
            If DataGridView1.RowCount = 1 Then
                MessageBox.Show("No items present. Please add at least one item.")

                Return
            End If
            For Each row As DataGridViewRow In DataGridView1.Rows
                If Not IsQuantityValid(row.Cells("qtty").Value?.ToString()) Then
                    MessageBox.Show("Please enter a quantity greater than 0")
                    DataGridView1.CurrentCell = row.Cells("qtty")
                    DataGridView1.BeginEdit(True)
                    Return
                End If

                If Not IsPriceValid(row.Cells("price1").Value?.ToString()) Then
                    MessageBox.Show("Please enter a Price greater than 0")
                    DataGridView1.CurrentCell = row.Cells("price1")
                    DataGridView1.BeginEdit(True)
                    Return
                End If

                If Not IsDiscountValid(row.Cells("discount1").Value?.ToString()) Then
                    MessageBox.Show("Discount must be between 0 and 100.")
                    DataGridView1.CurrentCell = row.Cells("discount1")
                    DataGridView1.BeginEdit(True)
                    Return
                End If
            Next
            SaveData()


            MessageBox.Show("SalesInvoice Modified successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub


    Private Function CheckIfBillExists(billNo As String) As Boolean
        Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

        ' Query to check if the bill exists in salesInvoicedetail table
        Dim detailQuery As String = "SELECT COUNT(*) FROM SalesInvoiceDetails WHERE Bill_no = @Bill_no"

        ' Query to check if the bill exists in salesInvoicemaster table
        Dim masterQuery As String = "SELECT COUNT(*) FROM salesInvoicemaster WHERE Bill_no = @Bill_no"

        Using connection As New SqlConnection(connectionString)
            connection.Open()

            ' Check if the bill exists in salesInvoicedetail table
            Using command As New SqlCommand(detailQuery, connection)
                command.Parameters.AddWithValue("@Bill_no", billNo)
                Dim detailCount As Integer = Convert.ToInt32(command.ExecuteScalar())
                If detailCount > 0 Then
                    Return True
                End If
            End Using

            ' Check if the bill exists in salesInvoicemaster table
            Using command As New SqlCommand(masterQuery, connection)
                command.Parameters.AddWithValue("@Bill_no", billNo)
                Dim masterCount As Integer = Convert.ToInt32(command.ExecuteScalar())
                If masterCount > 0 Then
                    Return True
                End If
            End Using
        End Using

        Return False
    End Function



    Private Sub ListBox3_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox3.KeyDown
        If e.KeyCode = Keys.Down Then
            If ListBox3.SelectedIndex = ListBox3.Items.Count - 1 Then
                e.SuppressKeyPress = True
                Return ' Do not move selection further down
            End If
        ElseIf e.KeyCode = Keys.Enter Then
            ' Hide ListBox3
            ListBox3.Visible = False
            Dim selectedItem As String = ListBox3.SelectedItem

            ' Call a separate function to fill the fields with data from the selected item
            FillFieldsWithData(selectedItem)
        End If
    End Sub
    Private Sub ListBox3_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles ListBox3.MouseDoubleClick
        ' Retrieve the selected item from ListBox3
        Dim selectedItem As String = ListBox3.SelectedItem

        ' Call a separate function to fill the fields with data from the selected item
        FillFieldsWithData(selectedItem)
    End Sub

    Private Sub FillFieldsWithData(selectedItem As String)
        ' Split the selected item into its components
        Dim selectedComponents As String() = selectedItem.Split(":"c)
        If selectedComponents.Length = 4 Then ' Ensure the selected item has the correct format
            ' Extract necessary data from the selected item
            Dim billNo1 As String = selectedComponents(0)
            Dim billDate As String = selectedComponents(1)
            Dim customerName As String = selectedComponents(2)
            Dim totalFinalAmt As String = selectedComponents(3)

            ' Fill the fields with data from salesInvoicemaster table
            Billno.Text = billNo1
            DateTimePicker1.Value = DateTime.ParseExact(billDate, "yyyy-MM-dd", CultureInfo.InvariantCulture)
            cust.Text = customerName
            TotalAmt.Text = totalFinalAmt

            ' Fetch address and mobile number from salesInvoicemaster for the selected billNo
            Dim addressQuery As String = "SELECT Address, Mobile_ni FROM salesInvoicemaster WHERE Bill_no = @Bill_no"
            Using connection As New SqlConnection("Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True")
                connection.Open()
                Using command As New SqlCommand(addressQuery, connection)
                    command.Parameters.AddWithValue("@Bill_no", billNo1)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        If reader.Read() Then
                            ' Extract address and mobile number
                            Dim address1 As String = reader("Address").ToString()
                            Dim mobileNumber As String = reader("Mobile_ni").ToString()
                            ' Fill address and mobile number fields
                            address.Text = address1
                            Mobile_number.Text = mobileNumber
                        End If
                    End Using
                End Using
            End Using

            ' Now fill DataGridView1 with data from salesInvoicedetail table for the selected billNo
            FillDataGridViewWithDetails(billNo1)
            ListBox3.Visible = False
            ListBox1.Visible = False

        Else
            MessageBox.Show("Selected item has invalid format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub


    Private Sub FillDataGridViewWithDetails(ByVal billNo As String)
        ' Clear any previous data in DataGridView1
        DataGridView1.Rows.Clear()

        ' Define a counter for the SrNo
        Dim srNoCounter As Integer = 1

        ' Fetch data from salesInvoicedetail table for the selected billNo
        Using connection As New SqlConnection("Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True")
            connection.Open()
            Dim query As String = "SELECT SID.*, ID.ItemDetail_id FROM SalesInvoiceDetails SID INNER JOIN ItemDetail ID ON SID.Item_name = ID.ItemName WHERE SID.Bill_no = @Bill_no"
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@Bill_no", billNo)
                Using reader As SqlDataReader = command.ExecuteReader()
                    While reader.Read()
                        ' Extract data from the reader
                        Dim itemID As String = reader("ItemDetail_id").ToString()
                        Dim itemName As String = reader("Item_name").ToString()
                        Dim manufacturer As String = reader("Manufature").ToString()
                        Dim itemType As String = reader("ItemType").ToString()
                        Dim batch As String = reader("Batch").ToString()
                        Dim godown As String = reader("Godown").ToString()
                        Dim qty As String = reader("Qty").ToString()
                        Dim price As String = reader("Price").ToString()
                        Dim disPercent As String = reader("Dis_Percent").ToString()
                        Dim disAmt As String = reader("Dis_Amt").ToString()
                        Dim gstPercent As String = reader("GST_Per").ToString()
                        Dim gstAmt As String = reader("GST_amt").ToString()
                        Dim amount As String = reader("Amount").ToString()
                        Dim totalAmt As String = reader("Total_Amt").ToString()
                        Dim sgstPer As String = reader("SGST_per").ToString()
                        Dim sgstAmt As String = reader("SGST_amt").ToString()
                        Dim cgstPer As String = reader("CGST_per").ToString()
                        Dim cgstAmt As String = reader("CGST_amt").ToString()

                        ' Add the data to DataGridView1 starting from the 3rd row and 3rd column
                        DataGridView1.Rows.Add(srNoCounter, itemID, itemName, manufacturer, itemType, batch, godown, qty, price, disPercent, disAmt, gstPercent, gstAmt, amount, totalAmt, sgstPer, sgstAmt, cgstPer, cgstAmt, "X")

                        ' Increment the SrNo counter
                        srNoCounter += 1
                    End While
                End Using
            End Using
        End Using
        CalculateColumnTotals()
    End Sub


    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
        Save.Enabled = False
        Modify.Enabled = False

        PerformDeletion()
    End Sub
    Private Sub PerformDeletion()
        ' Check if there are any rows in DataGridView1
        If TotalAmt.Text = "0" Then
            ' Proceed with deletion
            ListBox3.Visible = True

            ' Clear any previous items in ListBox3
            ListBox3.Items.Clear()

            ' Retrieve data from the salesInvoicemaster table and populate ListBox3
            Using connection As New SqlConnection("Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True")
                connection.Open()
                Dim query As String = "SELECT Bill_no, Bill_date, Customer_name, TotalFinalAmt FROM salesInvoicemaster"
                Using command As New SqlCommand(query, connection)
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            Dim billNo As String = reader("Bill_no").ToString()
                            Dim billDate As String = reader("Bill_date").ToString()
                            Dim customerName As String = reader("Customer_name").ToString()
                            Dim totalFinalAmt As String = reader("TotalFinalAmt").ToString()
                            ' Format the data into a single string and add it to ListBox3
                            Dim formattedString As String = $"{billNo}:{billDate}:{customerName}:{totalFinalAmt}"
                            ListBox3.Items.Add(formattedString)
                        End While
                    End Using
                End Using
            End Using
        Else
            ' If there are no rows in DataGridView1, display a message to the user
            ' If there are no rows in DataGridView1, proceed with deletion from salesInvoicedetail and salesInvoicemaster
            ' Get the selected item from ListBox3
            Dim selectedItem As String = ListBox3.SelectedItem
            If selectedItem IsNot Nothing Then
                ' Split the selected item into its components
                Dim selectedComponents As String() = selectedItem.Split(":"c)
                If selectedComponents.Length = 4 Then ' Ensure the selected item has the correct format
                    ' Extract necessary data from the selected item
                    Dim billNoToDelete As String = selectedComponents(0)

                    ' Insert data into Trashbin table
                    InsertIntoTrashbin(billNoToDelete)

                    ' Update stock from Trashbin
                    UpdateStockFromTrashbin()

                    ' Delete rows with the same billNo from salesInvoicedetail table
                    DeleteFromSalesInvoiceDetail(billNoToDelete)

                    ' Delete rows with the same billNo from salesInvoicemaster table
                    DeleteFromSalesInvoiceMaster(billNoToDelete)

                    ' Inform the user
                    MessageBox.Show("SalesInvoice deleted successfully.")
                    ClearForm()
                Else
                    MessageBox.Show("Selected item has invalid format.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If
            Else
                MessageBox.Show("Please select an item to delete.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub InsertIntoTrashbin(billNo As String)
        ' Define the connection string
        Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

        ' Define the insert query for Trashbin table
        Dim insertQueryTrashbin As String = "INSERT INTO Trashbin (Bill_no, Bill_date, Item_ID, Item_name, Manufature, ItemType, Batch, Godown, QtY, price, Dis_Percent, Dis_Amt, GST_Per, GST_amt, Amount, Total_Amt, SGST_per, SGST_amt, CGST_per, CGST_amt) " &
                                    "SELECT Bill_no, Bill_date, Item_ID, Item_name, Manufature, ItemType, Batch, Godown, QtY, price, Dis_Percent, Dis_Amt, GST_Per, GST_amt, Amount, Total_Amt, SGST_per, SGST_amt, CGST_per, CGST_amt " &
                                    "FROM SalesInvoiceDetails WHERE Bill_no = @Bill_no"

        ' Execute the insert query for Trashbin
        Using connection As New SqlConnection(connectionString)
            connection.Open()
            Using command As New SqlCommand(insertQueryTrashbin, connection)
                command.Parameters.AddWithValue("@Bill_no", billNo)
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Private Sub DeleteFromSalesInvoiceDetail(billNo As String)
        ' Define the connection string
        Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

        ' Define the delete query for salesInvoicedetail table


        ' Define the insert query for Trashbin table

        Dim deleteQueryDetail As String = "DELETE FROM SalesInvoiceDetails WHERE Bill_no = @Bill_no"
        ' Execute the delete query and insert into Trashbin
        Using connection As New SqlConnection(connectionString)
            connection.Open()

            ' Begin a transaction
            Dim transaction As SqlTransaction = connection.BeginTransaction()

            Try
                ' Execute the delete query
                Using deleteCommand As New SqlCommand(deleteQueryDetail, connection, transaction)
                    deleteCommand.Parameters.AddWithValue("@Bill_no", billNo)

                    deleteCommand.ExecuteNonQuery()
                End Using

                ' Execute the insert query for Trashbin


                ' Commit the transaction
                transaction.Commit()

                ' If successful, inform the user

            Catch ex As Exception
                ' If an error occurs, rollback the transaction
                transaction.Rollback()
                MessageBox.Show("An error occurred while deleting the item: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End Using
    End Sub


    Private Sub DeleteFromSalesInvoiceMaster(billNo As String)
        ' Define the connection string
        Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

        ' Define the delete query for salesInvoicemaster table
        Dim deleteQueryMaster As String = "DELETE FROM salesInvoicemaster WHERE Bill_no = @Bill_no"

        ' Execute the delete query
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(deleteQueryMaster, connection)
                command.Parameters.AddWithValue("@Bill_no", billNo)
                connection.Open()
                command.ExecuteNonQuery()
            End Using
        End Using
    End Sub
    Private Sub UpdateStockFromTrashbin()
        Try
            Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

            ' Fetch the data from Trashbin for the item with the highest sr_no
            Dim trashbinData As DataTable = New DataTable()
            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand("SELECT * FROM Trashbin ORDER BY sr_no DESC;", connection)
                    connection.Open()
                    Dim adapter As New SqlDataAdapter(command)
                    adapter.Fill(trashbinData)
                End Using
            End Using

            ' If no data found in Trashbin, return
            If trashbinData.Rows.Count = 0 Then
                MessageBox.Show("No data found in Trashbin.")
                Return
            End If

            ' Get the Item_ID and QtY from the Trashbin data
            Dim itemID As String = trashbinData.Rows(0)("Item_ID").ToString()
            Dim qty As Integer = Convert.ToInt32(trashbinData.Rows(0)("QtY"))

            ' Update the Closing_Stock in ItemDetail table
            Dim updateQuery As String = "UPDATE ItemDetail SET Closing_Stock = Closing_Stock + @Qty WHERE ItemDetail_id = @ItemID;"
            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand(updateQuery, connection)
                    command.Parameters.AddWithValue("@Qty", qty)
                    command.Parameters.AddWithValue("@ItemID", itemID)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using

            ' Truncate the Trashbin table after updating the stock
            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand("TRUNCATE TABLE Trashbin;", connection)
                    connection.Open()
                    command.ExecuteNonQuery()
                End Using
            End Using



        Catch ex As Exception
            MessageBox.Show("An error occurred while updating stock from Trashbin: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub qty_TextChanged(sender As Object, e As EventArgs) Handles qty.TextChanged
        ' Check if the entered quantity is a valid integer
        Dim enteredQty As Integer
        If Integer.TryParse(qty.Text, enteredQty) Then
            ' Fetch the current closing stock
            Dim currentClosingStock As Integer = GetCurrentClosingStock()

            ' Compare the entered quantity with the closing stock
            If enteredQty > currentClosingStock Then
                ' Display a message indicating that the entered quantity is greater than the available stock
                MessageBox.Show("Enter quantity less than or equal to the available stock (" & currentClosingStock & ").", "Stock Alert", MessageBoxButtons.OK, MessageBoxIcon.Warning)

                ' Set focus back to the qty textbox
                qty.Focus()
            End If
        Else
            ' If the entered text is not a valid integer, clear the textbox
            qty.Text = ""
        End If
    End Sub

    Private Function GetCurrentClosingStock() As Integer
        Try
            Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"
            Dim currentClosingStock As Integer

            Using connection As New SqlConnection(connectionString)
                Using command As New SqlCommand("SELECT Closing_Stock FROM ItemDetail WHERE ItemName = @ItemName;", connection)
                    ' Replace "ItemName" with the actual column name for the item name
                    command.Parameters.AddWithValue("@ItemName", Itemname.Text.Trim()) ' Assuming Itemname is the textbox for entering item name
                    connection.Open()
                    Dim result = command.ExecuteScalar()
                    If result IsNot Nothing AndAlso Integer.TryParse(result.ToString(), currentClosingStock) Then
                        Return currentClosingStock
                    Else
                        ' Handle the case where closing stock is not found or cannot be parsed as an integer
                        Return 0
                    End If
                End Using
            End Using
        Catch ex As Exception
            ' Handle any exceptions
            MessageBox.Show("Error: " & ex.Message)
            Return 0
        End Try
    End Function


    Private Sub Label10_Click_1(sender As Object, e As EventArgs)

    End Sub

    Private Sub Discount_TextChanged(sender As Object, e As EventArgs) Handles Discount.TextChanged

    End Sub
End Class