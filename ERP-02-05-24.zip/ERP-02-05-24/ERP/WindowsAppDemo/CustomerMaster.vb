﻿'Imports System.Data.SqlClient

'Public Class CustomerMaster
'    Private customerIdLoaded As Integer = 0
'    ' Define your connection string
'    Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"

'    Private Async Sub CustomerMaster_Load(sender As Object, e As EventArgs) Handles MyBase.Load
'        'TODO: This line of code loads data into the 'DemoItemDataSet11.States' table. You can move, or remove it, as needed.
'        Me.StatesTableAdapter.Fill(Me.DemoItemDataSet11.States)
'        ' Load data into ComboBoxes or perform any necessary setup when the form loads
'        Modify.Enabled = False
'        Delete.Enabled = False
'        Customer_ID.Enabled = False
'        State.SelectedIndex = -1

'        ' Set up auto-suggestion for the State ComboBox
'        State.AutoCompleteMode = AutoCompleteMode.SuggestAppend
'        State.AutoCompleteSource = AutoCompleteSource.ListItems
'        Await Task.Delay(100)
'        ' Set focus to the Customer Name textbox
'        Customer_name.Focus()
'    End Sub

'    Private Sub Customer_name_KeyDown(sender As Object, e As KeyEventArgs) Handles Customer_name.KeyDown
'        If ListBox1.Visible = True Then
'            If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
'                ListBox1.Focus()
'                e.SuppressKeyPress = True
'            End If
'        ElseIf ListBox1.Visible = False Then
'            If e.KeyCode = Keys.Down Then
'                Mobile_number.Focus()

'                e.SuppressKeyPress = True
'            End If
'            If e.KeyCode = Keys.Enter Then
'                Mobile_number.Focus()

'                e.SuppressKeyPress = True
'            End If
'        End If
'    End Sub

'    Private Sub ListBox_KeyDown(sender As Object, e As KeyEventArgs)
'        If e.KeyCode = Keys.Enter Then
'            If ListBox1.SelectedIndex <> -1 Then
'                AutofillSelectedCustomer()
'                ListBox1.Visible = False
'                Customer_name.Focus()
'                e.SuppressKeyPress = True
'            End If
'        ElseIf e.KeyCode = Keys.Down Then
'            If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
'                e.SuppressKeyPress = True
'                Return ' Do not move selection further down
'            End If
'        ElseIf e.KeyCode = Keys.Enter Then
'            Mobile_number.Focus()
'            ListBox1.Visible = False
'        End If
'        If e.KeyCode = Keys.Up Then
'            Customer_name.Focus()
'        End If
'    End Sub



'    Private Sub Mobile_number_KeyDown(sender As Object, e As KeyEventArgs) Handles Mobile_number.KeyDown
'        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
'            State.Focus()
'            e.SuppressKeyPress = True
'        End If
'        If e.KeyCode = Keys.Up Then
'            Customer_name.Focus()
'        End If
'    End Sub


'    Private Sub State_KeyDown(sender As Object, e As KeyEventArgs) Handles State.KeyDown


'        If e.KeyCode = Keys.Down Then
'            State.DroppedDown = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            Address.Focus()
'        End If
'        If e.KeyCode = Keys.Up Then
'            Mobile_number.Focus()
'        End If
'    End Sub

'    Private Sub Address_KeyDown(sender As Object, e As KeyEventArgs) Handles Address.KeyDown
'        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
'            Email.Focus()
'            e.SuppressKeyPress = True
'        End If
'        If e.KeyCode = Keys.Up Then
'            State.Focus()
'        End If
'    End Sub

'    Private Sub Email_KeyDown(sender As Object, e As KeyEventArgs) Handles Email.KeyDown
'        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
'            If customerIdLoaded = 0 Then
'                Save.Focus()
'            Else
'                Modify.Focus()
'            End If
'        End If
'        If e.KeyCode = Keys.Up Then
'            Address.Focus()
'        End If
'    End Sub


'    Private Sub SaveCustomer()
'        ' Check if Customer_Name is blank
'        If String.IsNullOrWhiteSpace(Customer_name.Text) Then
'            MessageBox.Show("Please Enter the Customer Name.")
'            Customer_name.Focus()
'            Return
'        End If

'        ' Check if Mobile_number is provided and valid
'        If Not String.IsNullOrEmpty(Mobile_number.Text) AndAlso (Not IsNumeric(Mobile_number.Text) OrElse Mobile_number.Text.Length <> 10) Then
'            MessageBox.Show("Please enter a valid 10-digit mobile number.")
'            Return
'        End If

'        ' Check if State is provided
'        If State.Text = "" Then
'            MessageBox.Show("Please Enter the State.")
'            Return
'        End If

'        ' Check if Email is provided and valid
'        If Not String.IsNullOrEmpty(Email.Text) AndAlso Not IsValidEmail(Email.Text) Then
'            MessageBox.Show("Please enter a valid email address.")
'            Return
'        End If

'        ' Check if the Customer_Name already exists
'        If Not IsCustomerNameUnique(Customer_name.Text) Then
'            MessageBox.Show("A customer already exists.")
'            Return
'        End If

'        ' Implement the logic to save customer information into the database
'        ' Define your SQL query to insert data into the CustomerMaster table
'        Dim query As String = "INSERT INTO CustomerMaster (Customer_Name, Mobile_number, State, Address, Email) VALUES (@Customer_Name, @Mobile_number, @State, @Address, @Email)"

'        ' Create a SqlConnection object
'        Using connection As New SqlConnection(connectionString)
'            ' Create a SqlCommand object with the query and connection
'            Using command As New SqlCommand(query, connection)
'                ' Set the parameter values for the query
'                command.Parameters.AddWithValue("@Customer_Name", Customer_name.Text.ToUpper()) ' Convert Customer_Name to uppercase
'                command.Parameters.AddWithValue("@Mobile_number", Mobile_number.Text)
'                command.Parameters.AddWithValue("@State", State.Text)
'                command.Parameters.AddWithValue("@Address", Address.Text)
'                command.Parameters.AddWithValue("@Email", Email.Text)

'                Try
'                    ' Open the connection
'                    connection.Open()
'                    ' Execute the SQL command
'                    command.ExecuteNonQuery()
'                    MessageBox.Show("Customer saved successfully.")
'                    ClearForm()
'                Catch ex As Exception
'                    MessageBox.Show("Error saving customer: " & ex.Message)
'                End Try
'            End Using
'        End Using
'    End Sub

'    Private Function IsValidEmail(email As String) As Boolean
'        ' Regular expression pattern for validating email
'        Dim pattern As String = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"
'        ' Checking if the email matches the pattern
'        Return System.Text.RegularExpressions.Regex.IsMatch(email, pattern)
'    End Function

'    Private Function IsCustomerNameUnique(customerName As String) As Boolean
'        Dim query As String = "SELECT COUNT(*) FROM CustomerMaster WHERE Customer_Name = @Customer_Name"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                command.Parameters.AddWithValue("@Customer_Name", customerName)
'                connection.Open()
'                Dim count As Integer = CInt(command.ExecuteScalar())
'                Return count = 0
'            End Using
'        End Using
'    End Function
'    Private Sub ListBox1_MouseDoubleClick(sender As Object, e As MouseEventArgs)
'        AutofillSelectedCustomer()
'    End Sub
'    Private Sub ModifyCustomer()

'        ' Implement the logic to modify existing customer information in the database
'        ' Define your SQL query to update data in the CustomerMaster table
'        If String.IsNullOrWhiteSpace(Customer_name.Text) Then
'            MessageBox.Show("Please Enter the Customer Name.")
'            Customer_name.Focus()
'            Return
'        End If
'        If Not String.IsNullOrEmpty(Mobile_number.Text) AndAlso (Not IsNumeric(Mobile_number.Text) OrElse Mobile_number.Text.Length <> 10) Then
'            MessageBox.Show("Please enter a valid 10-digit mobile number.")
'            Return
'        End If
'        If State.Text = "" Then
'            MessageBox.Show("Please Enter the State.")
'            Return
'        End If
'        If Not String.IsNullOrEmpty(Email.Text) AndAlso Not IsValidEmail(Email.Text) Then
'            MessageBox.Show("Please enter a valid email address.")
'            Return
'        End If

'        If Not IsCustomerNameUnique(Customer_name.Text) Then
'            MessageBox.Show("A customer with the same name already exists.")
'            Return
'        End If
'        Dim query As String = "UPDATE CustomerMaster SET Customer_Name = @Customer_Name, Mobile_number = @Mobile_number, State = @State, Address = @Address, Email = @Email WHERE Customer_ID = @Customer_ID"

'        ' Create a SqlConnection object
'        Using connection As New SqlConnection(connectionString)
'            ' Create a SqlCommand object with the query and connection
'            Using command As New SqlCommand(query, connection)
'                ' Set the parameter values for the query
'                command.Parameters.AddWithValue("@Customer_ID", Customer_ID.Text.ToUpper())
'                command.Parameters.AddWithValue("@Customer_Name", Customer_name.Text)
'                command.Parameters.AddWithValue("@Mobile_number", Mobile_number.Text)
'                command.Parameters.AddWithValue("@State", State.Text)
'                command.Parameters.AddWithValue("@Address", Address.Text)
'                command.Parameters.AddWithValue("@Email", Email.Text)

'                Try
'                    ' Open the connection
'                    connection.Open()
'                    ' Execute the SQL command
'                    command.ExecuteNonQuery()
'                    MessageBox.Show("Customer modified successfully.")
'                    ClearForm()
'                Catch ex As Exception
'                    MessageBox.Show("Error modifying customer: " & ex.Message)
'                    ClearForm()
'                End Try
'            End Using
'        End Using
'    End Sub


'    Private Sub DeleteCustomer()
'        ' Implement the logic to delete a customer record from the database
'        ' Define your SQL query to delete data from the CustomerMaster table
'        Dim query As String = "DELETE FROM CustomerMaster WHERE Customer_ID = @Customer_ID"

'        ' Create a SqlConnection object
'        Using connection As New SqlConnection(connectionString)
'            ' Create a SqlCommand object with the query and connection
'            Using command As New SqlCommand(query, connection)
'                ' Set the parameter value for the Customer_ID
'                command.Parameters.AddWithValue("@Customer_ID", Customer_ID.Text)

'                Try
'                    ' Open the connection
'                    connection.Open()
'                    ' Execute the SQL command
'                    Dim rowsAffected As Integer = command.ExecuteNonQuery()
'                    If rowsAffected > 0 Then
'                        MessageBox.Show("Customer deleted successfully.")
'                        ClearForm()
'                    Else
'                        MessageBox.Show("No customer found with the specified ID.")
'                    End If
'                    ClearForm()
'                Catch ex As Exception
'                    MessageBox.Show("Error deleting customer: " & ex.Message)
'                    ClearForm()
'                End Try
'            End Using
'        End Using
'    End Sub


'    Private Sub ClearForm()
'        ' Clear all the textboxes or reset the form
'        Customer_ID.Text = ""
'        Customer_name.Text = ""
'        Mobile_number.Text = ""
'        State.Text = ""
'        Address.Text = ""
'        Email.Text = ""
'        ListBox1.Visible = False
'        Save.Visible = True
'        Modify.Visible = False
'        Delete.Enabled = False
'        Customer_name.Focus()
'        customerIdLoaded = 0
'    End Sub

'    Private Sub Save_Click(sender As Object, e As EventArgs) Handles Save.Click
'        ' Call the SaveCustomer method when the save button is clicked
'        SaveCustomer()
'    End Sub

'    Private Sub Modify_Click(sender As Object, e As EventArgs) Handles Modify.Click
'        ' Call the ModifyCustomer method when the modify button is clicked
'        ModifyCustomer()
'    End Sub

'    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
'        ' Call the DeleteCustomer method when the delete button is clicked
'        DeleteCustomer()
'    End Sub

'    Private Sub Customer_name_TextChanged(sender As Object, e As EventArgs) Handles Customer_name.TextChanged

'        Dim searchText As String = Customer_name.Text.Trim()

'        ' Call the LoadSimilarCustomers function to load similar customers based on the entered text
'        LoadSimilarCustomers(searchText)

'        ' Hide the ListBox1 if Customer_name is empty
'        If String.IsNullOrWhiteSpace(Customer_name.Text) Then
'            ListBox1.Visible = False
'        End If
'        ' Call the LoadSimilarCustomers function to load similar customers based on the entered text

'    End Sub


'    Private Sub LoadSimilarCustomers(searchText As String)
'        Try
'            ' Clear the list box items
'            ListBox1.Items.Clear()

'            ' Define your SQL query to search for similar customers
'            Dim query As String = "SELECT Customer_ID, Customer_Name, Mobile_number, State, Address, Email FROM CustomerMaster WHERE Customer_Name LIKE @SearchText + '%'"

'            ' Create a SqlConnection object
'            Using connection As New SqlConnection(connectionString)
'                ' Create a SqlCommand object with the query and connection
'                Using command As New SqlCommand(query, connection)
'                    ' Set the parameter value for the search text
'                    command.Parameters.AddWithValue("@SearchText", searchText)

'                    ' Open the connection
'                    connection.Open()

'                    ' Execute the SQL command and retrieve the matching customer details
'                    Using reader As SqlDataReader = command.ExecuteReader()
'                        While reader.Read()
'                            ' Construct the customer string with Customer_ID, Customer_Name, Mobile_number, State, Address, and Email
'                            Dim customerString As String = $"{reader("Customer_ID")} : {reader("Customer_Name")} : {reader("Mobile_number")} : {reader("State")} : {reader("Address")} : {reader("Email")}"
'                            ' Add the customer string to ListBox1
'                            ListBox1.Items.Add(customerString)
'                        End While
'                    End Using
'                End Using
'            End Using

'            ' Show ListBox1 with matching customer details
'            If ListBox1.Items.Count > 0 Then
'                ListBox1.Visible = True
'            ElseIf Customer_name.Text = " " Then
'                ListBox1.Visible = False
'            Else
'                ListBox1.Visible = False
'            End If
'        Catch ex As Exception
'            MessageBox.Show("Error loading similar customers: " & ex.Message)
'        End Try
'    End Sub

'    Private Sub AutofillSelectedCustomer()
'        ' Check if an item is selected in the list box
'        If ListBox1.SelectedIndex <> -1 Then
'            ' Split the selected customer string to extract individual details
'            Dim selectedCustomerDetails As String() = ListBox1.SelectedItem.ToString().Split(":"c)

'            ' Autofill the form with the selected customer details
'            If selectedCustomerDetails.Length >= 6 Then
'                Customer_ID.Text = selectedCustomerDetails(0).Trim()
'                Customer_name.Text = selectedCustomerDetails(1).Trim()
'                Mobile_number.Text = selectedCustomerDetails(2).Trim()
'                State.Text = selectedCustomerDetails(3).Trim()
'                Address.Text = selectedCustomerDetails(4).Trim()
'                Email.Text = selectedCustomerDetails(5).Trim()
'                ' Autofill other fields similarly
'                Save.Visible = False
'                Modify.Visible = True
'                Delete.Enabled = True
'                Modify.Enabled = True
'                Modify.Focus()
'                customerIdLoaded = 1
'            Else
'                MessageBox.Show("Error: Incomplete customer details.")
'            End If

'            ' Hide the ListBox after an item is selected
'            ListBox1.Visible = False
'        End If
'    End Sub
'    Private Sub ListBox1_DoubleClick(sender As Object, e As EventArgs)
'        AutofillSelectedCustomer()
'    End Sub

'    Private Sub ListBox1_KeyDown(sender As Object, e As KeyEventArgs)
'        If e.KeyCode = Keys.Enter Then
'            AutofillSelectedCustomer()
'        End If
'    End Sub

'    Private Sub Cancel_Click(sender As Object, e As EventArgs) Handles Cancel.Click
'        ClearForm()
'    End Sub

'    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click
'        Me.Dispose()
'    End Sub


'    Private Sub Mobile_number_KeyPress(sender As Object, e As KeyPressEventArgs) Handles Mobile_number.KeyPress
'        ' Allowing only numeric characters and backspace
'        If Not Char.IsDigit(e.KeyChar) AndAlso Not Char.IsControl(e.KeyChar) Then
'            e.Handled = True
'        End If

'        ' Limiting the length to 10 characters
'        If Mobile_number.Text.Length >= 10 AndAlso Not Char.IsControl(e.KeyChar) Then
'            e.Handled = True
'        End If
'    End Sub
'    Private Sub Modify_KeyDown(sender As Object, e As KeyEventArgs) Handles Modify.KeyDown
'        If e.KeyCode = Keys.Right Then
'            Delete.Focus()
'            e.Handled = True ' Prevent further processing of the right arrow key
'        End If
'    End Sub


'    Private Sub Email_Leave(sender As Object, e As EventArgs) Handles Email.Leave
'        ' Check if Email is provided and valid
'        If Not String.IsNullOrEmpty(Email.Text) AndAlso Not IsValidEmail(Email.Text) Then
'            Label7.Text = "Please enter a valid email address."
'            Email.Focus()
'        Else
'            Label7.Text = "" ' Clear the error message if the email is valid
'        End If
'    End Sub

'    Private Sub Email_TextChanged(sender As Object, e As EventArgs) Handles Email.TextChanged
'        If Not String.IsNullOrEmpty(Email.Text) AndAlso Not IsValidEmail(Email.Text) Then
'            Label7.Text = "Please enter a valid email address."
'            Email.Focus()
'        Else
'            Label7.Text = "" ' Clear the error message if the email is valid
'        End If
'    End Sub







'    ' Add event handlers for other controls as needed

'End Class
