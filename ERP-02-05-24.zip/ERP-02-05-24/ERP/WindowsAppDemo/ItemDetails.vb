﻿'Imports System.Data.SqlClient

'Public Class ItemDetails

'    Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"
'    Private Sub ItemDetails_Load(sender As Object, e As EventArgs) Handles MyBase.Load
'        'TODO: This line of code loads data into the 'DemoItemDataSet10.ItemDetail' table. You can move, or remove it, as needed.
'        Me.ItemDetailTableAdapter.Fill(Me.DemoItemDataSet10.ItemDetail)
'        'TODO: This line of code loads data into the 'DemoItemDataSet9.Unit' table. You can move, or remove it, as needed.
'        Me.UnitTableAdapter.Fill(Me.DemoItemDataSet9.Unit)
'        ' Populate the Manufacturer (mfr) combo box
'        PopulateManufacturerComboBox()

'        ' Populate the Item type combo box
'        PopulateItemTypeComboBox()
'        Manufature1.Enabled = True
'        Itemtype.Enabled = True
'        Closing_Stock.Enabled = False
'        Manufature1.AutoCompleteMode = AutoCompleteMode.SuggestAppend
'        Manufature1.AutoCompleteSource = AutoCompleteSource.ListItems
'        Itemtype.AutoCompleteMode = AutoCompleteMode.SuggestAppend
'        Itemtype.AutoCompleteSource = AutoCompleteSource.ListItems
'    End Sub


'    Private Sub PopulateManufacturerComboBox()
'        Try
'            ' Clear existing items
'            Manufature1.Items.Clear()

'            ' Define SQL query to fetch manufacturer names
'            Dim query As String = "SELECT Mfrname FROM MfrMaster"

'            ' Create SqlConnection and SqlCommand objects
'            Using connection As New SqlConnection(connectionString)
'                Using command As New SqlCommand(query, connection)
'                    ' Open connection
'                    connection.Open()

'                    ' Execute the query
'                    Using reader As SqlDataReader = command.ExecuteReader()
'                        While reader.Read()
'                            ' Add manufacturer name to combo box
'                            Manufature1.Items.Add(reader("Mfrname").ToString())
'                        End While
'                    End Using
'                End Using
'            End Using
'        Catch ex As Exception
'            MessageBox.Show("Error populating Manufacturer combo box: " & ex.Message)
'            ClearFields()
'        End Try
'    End Sub

'    Private Sub PopulateItemTypeComboBox()
'        Try
'            ' Clear existing items
'            Itemtype.Items.Clear()

'            ' Define SQL query to fetch item types
'            Dim query As String = "SELECT Itemtype FROM ItemtypeMaster"

'            ' Create SqlConnection and SqlCommand objects
'            Using connection As New SqlConnection(connectionString)
'                Using command As New SqlCommand(query, connection)
'                    ' Open connection
'                    connection.Open()

'                    ' Execute the query
'                    Using reader As SqlDataReader = command.ExecuteReader()
'                        While reader.Read()
'                            ' Add item type to combo box
'                            Itemtype.Items.Add(reader("Itemtype").ToString())
'                        End While
'                    End Using
'                End Using
'            End Using
'        Catch ex As Exception
'            MessageBox.Show("Error populating Item type combo box: " & ex.Message)
'            ClearFields()
'        End Try
'    End Sub

'    Private Sub ItemName_KeyDown(sender As Object, e As KeyEventArgs) Handles ItemName.KeyDown
'        If ListBox1.Visible = True Then
'            If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
'                ListBox1.Focus()
'                e.SuppressKeyPress = True
'            End If
'        ElseIf ListBox1.Visible = False Then
'            If e.KeyCode = Keys.Down Then
'                Manufature1.Focus()

'                e.SuppressKeyPress = True
'            End If
'            If e.KeyCode = Keys.Enter Then
'                Batch.Focus()

'                e.SuppressKeyPress = True
'            End If
'        End If
'    End Sub
'    Private Sub ListBox1_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles ListBox1.MouseDoubleClick
'        AutofillSelectedItem()
'    End Sub
'    Private Sub ListBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox1.KeyDown
'        If e.KeyCode = Keys.Enter Then
'            If ListBox1.SelectedIndex <> -1 Then
'                AutofillSelectedItem()
'                ListBox1.Visible = False
'                ItemName.Focus()
'                e.SuppressKeyPress = True
'            End If
'        ElseIf e.KeyCode = Keys.Down Then
'            If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
'                e.SuppressKeyPress = True
'                Return ' Do not move selection further down
'            End If
'        ElseIf e.KeyCode = Keys.Enter Then
'            If Manufature1.Text = " " Then
'                Manufature1.Focus()
'                ListBox1.Visible = False
'            End If
'        ElseIf e.KeyCode = Keys.Enter Then
'            Manufature1.Focus()
'            ListBox1.Visible = False
'        End If
'    End Sub

'    Private Sub Manufature_KeyDown(sender As Object, e As KeyEventArgs) Handles Manufature1.KeyDown
'        If e.KeyCode = Keys.Down Then
'            Manufature1.DroppedDown = True

'        ElseIf e.KeyCode = Keys.Enter Then
'            Itemtype.Focus()
'            e.Handled = True ' Prevent default behavior of combo box to ensure Enter key moves focus
'        End If
'    End Sub

'    Private Sub Itemtype_KeyDown(sender As Object, e As KeyEventArgs) Handles Itemtype.KeyDown
'        If e.KeyCode = Keys.Down Then
'            Itemtype.DroppedDown = True

'        ElseIf e.KeyCode = Keys.Enter Then
'            Batch.Focus()
'            e.Handled = True ' Prevent default behavior of combo box to ensure Enter key moves focus
'        End If
'    End Sub

'    Private Sub Batch_KeyDown(sender As Object, e As KeyEventArgs) Handles Batch.KeyDown
'        If e.KeyCode = Keys.Down Then


'            Godown.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            If Godown.Text = " " Then
'                Godown.Focus()
'            End If

'            If e.KeyCode = Keys.Enter Then
'                GST.Focus()

'            End If
'        End If

'    End Sub

'    Private Sub Godown_KeyDown(sender As Object, e As KeyEventArgs) Handles Godown.KeyDown
'        If e.KeyCode = Keys.Down Then
'            Pakage.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            Pakage.Focus()
'        End If
'    End Sub

'    Private Sub Pakage_KeyDown(sender As Object, e As KeyEventArgs) Handles Pakage.KeyDown
'        If e.KeyCode = Keys.Down Then
'            GST.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            GST.Focus()
'        End If
'    End Sub

'    Private Sub GST_KeyDown(sender As Object, e As KeyEventArgs) Handles GST.KeyDown
'        If e.KeyCode = Keys.Down Then
'            Opening_Stock.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            Opening_Stock.Focus()
'        End If
'    End Sub

'    Private Sub Opening_Stock_KeyDown(sender As Object, e As KeyEventArgs) Handles Opening_Stock.KeyDown
'        If e.KeyCode = Keys.Down Then
'            MRP.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            MRP.Focus()
'        End If
'    End Sub



'    Private Sub MRP_KeyDown(sender As Object, e As KeyEventArgs) Handles MRP.KeyDown
'        If e.KeyCode = Keys.Down Then
'            Unit.Focus()
'            e.SuppressKeyPress = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            If Unit.Text = " " Then
'                Unit.Focus()
'            End If
'            If e.KeyCode = Keys.Enter Then
'                Save.Focus()
'            End If
'        End If
'    End Sub

'    Private Sub Unit_KeyDown(sender As Object, e As KeyEventArgs) Handles Unit.KeyDown
'        If e.KeyCode = Keys.Down Then
'            ' Open the drop-down list
'            Unit.DroppedDown = True
'        ElseIf e.KeyCode = Keys.Enter Then
'            ' If Save button is visible, focus on it; otherwise, focus on Modify button
'            If Save.Visible Then
'                Save.Focus()
'            ElseIf Modify.Visible Then
'                Modify.Focus()
'            End If
'            e.SuppressKeyPress = True ' Prevent default behavior of ComboBox
'        End If
'    End Sub


'    Private Sub ItemName_TextChanged(sender As Object, e As EventArgs) Handles ItemName.TextChanged
'        Dim searchText As String = ItemName.Text.Trim()

'        If searchText <> "" Then
'            ' Load matching items only if the text is not empty
'            LoadMatchingItems(searchText)

'            ' Check if the entered item name matches any item in the ListBox
'            Dim matchingItemExists As Boolean = False
'            For Each item As String In ListBox1.Items
'                If item.ToLower().Contains(searchText.ToLower()) Then
'                    matchingItemExists = True
'                    Exit For
'                End If
'            Next

'            ' Set ListBox visibility based on the matchingItemExists flag
'            ListBox1.Visible = matchingItemExists
'        Else
'            ' If the text is empty, hide the ListBox
'            ListBox1.Visible = False
'        End If
'    End Sub

'    Private Sub LoadMatchingItems(searchText As String)
'        Try
'            ' Clear the list box items
'            ListBox1.Items.Clear()

'            ' Define your SQL query to search for items similar to the entered text (case-insensitive)
'            Dim query As String = "SELECT master_id, ItemName, Mfrname, Itemtype, Description, Godown, pakage, unit FROM Itemmaster " &
'                              "INNER JOIN MfrMaster ON Itemmaster.mfr_id = MfrMaster.mfr_Id " &
'                              "INNER JOIN ItemtypeMaster ON Itemmaster.item_id = ItemtypeMaster.item_id " &
'                              "WHERE LOWER(ItemName) LIKE LOWER(@SearchText) + '%'"

'            ' Create a SqlConnection object
'            Using connection As New SqlConnection(connectionString)
'                ' Create a SqlCommand object with the query and connection
'                Using command As New SqlCommand(query, connection)
'                    ' Set the parameter value for the search text (converted to lowercase)
'                    command.Parameters.AddWithValue("@SearchText", searchText.ToLower())

'                    ' Open the connection
'                    connection.Open()

'                    ' Execute the SQL command and retrieve the matching items
'                    Using reader As SqlDataReader = command.ExecuteReader()
'                        While reader.Read()
'                            ' Construct the item string with master_id and add it to the list box
'                            Dim itemString As String = $"{reader("master_id")} : {reader("ItemName")} : {reader("Mfrname")} : {reader("Itemtype")} : {reader("Description")} : {reader("Godown")} : {reader("pakage")} : {reader("unit")}"
'                            ListBox1.Items.Add(itemString)
'                        End While
'                    End Using
'                End Using
'            End Using
'        Catch ex As Exception
'            MessageBox.Show("Error loading matching items: " & ex.Message)
'            ClearFields()
'        End Try
'    End Sub




'    ' Autofill the selected item details

'    Private Sub Save_Click(sender As Object, e As EventArgs) Handles Save.Click
'        Try
'            ' Check if required fields are empty
'            If ItemName.Text.Trim() = "" Then
'                MessageBox.Show("Please enter Item Name.")
'                Return
'            End If
'            If Manufature1.Text.Trim() = "" Then
'                MessageBox.Show("Please select Manufacturer.")
'                Return
'            End If

'            If Itemtype.Text.Trim() = "" Then
'                MessageBox.Show("Please select Item type.")
'                Return
'            End If
'            If Batch.Text.Trim() = "" Then
'                MessageBox.Show("Please enter Batch.")
'                Return
'            End If

'            If Godown.Text.Trim() = "" Then
'                MessageBox.Show("Please enter Godown.")
'                Return
'            End If

'            If Pakage.Text.Trim() = "" Then
'                MessageBox.Show("Please enter Pakage.")
'                Return
'            End If
'            If Unit.Text.Trim() = "" Then
'                MessageBox.Show("Please enter Unit.")
'                Return
'            End If

'            Dim gstValue As Decimal
'            If Not Decimal.TryParse(GST.Text.Trim(), gstValue) AndAlso GST.Text.Trim() <> "" Then
'                MessageBox.Show("GST must be a numeric value.")
'                Return
'            End If

'            ' Validate Opening Stock
'            Dim openingStockValue As Decimal
'            If Not Decimal.TryParse(Opening_Stock.Text.Trim(), openingStockValue) AndAlso Opening_Stock.Text.Trim() <> "" Then
'                MessageBox.Show("Opening Stock must be a numeric value.")
'                Return
'            End If

'            ' Validate MRP
'            Dim mrpValue As Decimal
'            If Not Decimal.TryParse(MRP.Text.Trim(), mrpValue) AndAlso MRP.Text.Trim() <> "" Then
'                MessageBox.Show("MRP must be a numeric value.")
'                Return
'            End If
'            ' Your code to proceed to the next item goes here

'            If DataExistsInItemDetailTable(ItemName.Text.Trim(), Batch.Text.Trim(), Godown.Text.Trim(), Pakage.Text.Trim()) Then
'                MessageBox.Show("Item  already exists.")

'                ClearFields()
'                Return
'            End If
'            ' Retrieve the master_id from the ItemMaster table based on the selected ItemName
'            Dim masterId As Integer = GetMasterId(ItemName.Text.Trim())

'            ' Insert data into ItemDetail table
'            Dim query As String = "INSERT INTO ItemDetail (ItemName, Batch, Godown, Pakage, Unit, Opening_Stock, Closing_Stock, MRP, GST, master_id) " &
'                              "VALUES (@ItemName, @Batch, @Godown, @Pakage, @Unit, @Opening_Stock,@Opening_Stock, @MRP, @GST, @master_id)"

'            Using connection As New SqlConnection(connectionString)
'                Using command As New SqlCommand(query, connection)
'                    connection.Open()

'                    ' Set parameter values
'                    command.Parameters.AddWithValue("@ItemName", ItemName.Text.Trim())
'                    command.Parameters.AddWithValue("@Batch", Batch.Text.Trim())
'                    command.Parameters.AddWithValue("@Godown", Godown.Text.Trim())
'                    command.Parameters.AddWithValue("@Pakage", Pakage.Text.Trim())
'                    command.Parameters.AddWithValue("@Unit", Unit.Text.Trim())
'                    command.Parameters.AddWithValue("@Opening_Stock", Opening_Stock.Text.Trim())
'                    command.Parameters.AddWithValue("@Closing_Stock", Closing_Stock.Text.Trim())
'                    command.Parameters.AddWithValue("@MRP", MRP.Text.Trim())
'                    command.Parameters.AddWithValue("@GST", GST.Text.Trim())

'                    ' If master_id is found, use it; otherwise, insert NULL
'                    If masterId <> -1 Then
'                        command.Parameters.AddWithValue("@master_id", masterId)
'                    Else
'                        command.Parameters.AddWithValue("@master_id", DBNull.Value)
'                    End If

'                    ' Execute the SQL command
'                    command.ExecuteNonQuery()

'                    MessageBox.Show("Item saved successfully.")
'                    ClearFields()
'                End Using
'            End Using
'        Catch ex As Exception
'            MessageBox.Show("Error saving data: " & ex.Message)
'        End Try
'    End Sub


'    Private Function DataExistsInItemDetailTable(itemName As String, batch As String, godown As String, pakage As String) As Boolean
'        Dim query As String = "SELECT COUNT(*) FROM ItemDetail WHERE ItemName = @ItemName AND Batch = @Batch AND Godown = @Godown AND Pakage = @Pakage"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                ' Set parameter values
'                command.Parameters.AddWithValue("@ItemName", itemName)
'                command.Parameters.AddWithValue("@Batch", batch)
'                command.Parameters.AddWithValue("@Godown", godown)
'                command.Parameters.AddWithValue("@Pakage", pakage)

'                ' Execute the query to check if data exists
'                Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

'                ' Return True if data exists, False otherwise
'                Return count > 0
'            End Using
'        End Using
'    End Function






'    Private Function GetMasterId(itemName As String) As Integer
'        Dim query As String = "SELECT master_id FROM ItemMaster WHERE ItemName = @ItemName"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                command.Parameters.AddWithValue("@ItemName", itemName)
'                Dim result As Object = command.ExecuteScalar()

'                If result IsNot Nothing AndAlso Not DBNull.Value.Equals(result) Then
'                    Return Convert.ToInt32(result)
'                End If
'            End Using
'        End Using

'        Return -1 ' Return -1 if not found
'    End Function

'    Private Sub Clear_Click(sender As Object, e As EventArgs) Handles Clear.Click
'        ClearFields()
'    End Sub



'    Private Sub ClearFields()
'        ' Clear all fields
'        ItemName.Clear()
'        Manufature1.SelectedIndex = -1
'        Itemtype.SelectedIndex = -1
'        Godown.Clear()
'        Pakage.Clear()
'        Unit.SelectedIndex = -1
'        Batch.Clear()
'        Opening_Stock.Clear()
'        Closing_Stock.Text = " "
'        MRP.Clear()
'        GST.Clear()
'        ListBox1.Visible = False
'        ListBox2.Visible = False
'        Manufature1.Enabled = True
'        Itemtype.Enabled = True
'        Godown.Enabled = True
'        Pakage.Enabled = True
'        Unit.Enabled = True
'        Save.Visible = True
'    End Sub



'    Private Sub AutofillSelectedItem()
'        ' Check if an item is selected in the list box
'        If ListBox1.SelectedIndex <> -1 Then
'            ' Split the selected item string to extract individual details
'            Dim selectedItemDetails As String() = ListBox1.SelectedItem.ToString().Split(":"c)

'            ' Autofill the form with the selected item details
'            If selectedItemDetails.Length >= 7 Then
'                ' Use the original casing entered by the user
'                ItemName.Text = selectedItemDetails(1).Trim()
'                Manufature1.Text = selectedItemDetails(2).Trim()
'                Itemtype.Text = selectedItemDetails(3).Trim()
'                Godown.Text = selectedItemDetails(5).Trim()
'                Pakage.Text = selectedItemDetails(6).Trim()
'                Unit.Text = selectedItemDetails(7).Trim()

'                Manufature1.Enabled = False
'                Itemtype.Enabled = False
'                Godown.Enabled = False
'                Pakage.Enabled = False
'                Unit.Enabled = False


'                ' Enable the Modify button and disable the Save button

'            Else
'                MessageBox.Show("Error: Incomplete item details.")
'                ClearFields()
'            End If

'            ' Hide the ListBox after an item is selected
'            ListBox1.Visible = False
'        End If
'    End Sub

'    Private Sub Modify_Click(sender As Object, e As EventArgs) Handles Modify.Click
'        If Manufature1.Text.Trim() = "" Then
'            Try
'                ' Call the method to load items into ListBox2
'                LoadItemsIntoListBox2()

'                ' Make ListBox2 visible
'                ListBox2.Visible = True

'                If ListBox2.Visible = False Then
'                    ' Check if ListBox2 is empty
'                    If ListBox2.Items.Count = 0 Then
'                        MessageBox.Show("The list is empty. Please add items before modifying.")
'                        ListBox2.Visible = False ' Hide ListBox2 if it's empty
'                        Return
'                    End If

'                    ' Check if required fields are empty
'                    If ItemName.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Item Name.")
'                        Return
'                    End If

'                    If Manufature1.Text.Trim() = "" Then
'                        MessageBox.Show("Please select Manufacturer.")
'                        Return
'                    End If

'                    If Itemtype.Text.Trim() = "" Then
'                        MessageBox.Show("Please select Item type.")
'                        Return
'                    End If

'                    If Batch.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Batch.")
'                        Return
'                    End If

'                    If Godown.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Godown.")
'                        Return
'                    End If

'                    If Pakage.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Pakage.")
'                        Return
'                    End If


'                    Dim gstValue As Decimal
'                    If Not Decimal.TryParse(GST.Text.Trim(), gstValue) AndAlso GST.Text.Trim() <> "" Then
'                        MessageBox.Show("GST must be a numeric value.")
'                        Return
'                    End If

'                    ' Validate Opening Stock
'                    Dim openingStockValue As Decimal
'                    If Not Decimal.TryParse(Opening_Stock.Text.Trim(), openingStockValue) AndAlso Opening_Stock.Text.Trim() <> "" Then
'                        MessageBox.Show("Opening Stock must be a numeric value.")
'                        Return
'                    End If

'                    ' Validate MRP
'                    Dim mrpValue As Decimal
'                    If Not Decimal.TryParse(MRP.Text.Trim(), mrpValue) AndAlso MRP.Text.Trim() <> "" Then
'                        MessageBox.Show("MRP must be a numeric value.")
'                        Return
'                    End If
'                    ' Your code to proceed to the next item goes here


'                    ' Check if the data exists in the ItemDetail table

'                    ' Data doesn't exist in ItemDetail table, treat it as a new item and insert
'                    ModifyItemDetail()
'                        MessageBox.Show("Item modified successfully.")
'                        ClearFields()


'                    ' Clear fields after modification or saving
'                    ClearFields()
'                    Manufature1.Enabled = True
'                    Itemtype.Enabled = True
'                End If
'            Catch ex As Exception
'                MessageBox.Show("Error modifying data: " & ex.Message)
'            End Try
'        Else
'            Try
'                ' Check if required fields are empty
'                If ItemName.Text.Trim() = "" Then
'                    MessageBox.Show("Please enter Item Name.")
'                    Return
'                End If
'                If Manufature1.Text.Trim() = "" Then
'                    MessageBox.Show("Please select Manufacturer.")
'                    Return
'                End If
'                If Itemtype.Text.Trim() = "" Then
'                    MessageBox.Show("Please select Item type.")
'                    Return
'                End If
'                If Batch.Text.Trim() = "" Then
'                    MessageBox.Show("Please enter Batch.")
'                    Return
'                End If
'                If Godown.Text.Trim() = "" Then
'                    MessageBox.Show("Please enter Godown.")
'                    Return
'                End If
'                If Pakage.Text.Trim() = "" Then
'                    MessageBox.Show("Please enter Pakage.")
'                    Return
'                End If

'                Dim gstValue As Decimal
'                If Not Decimal.TryParse(GST.Text.Trim(), gstValue) AndAlso GST.Text.Trim() <> "" Then
'                    MessageBox.Show("GST must be a numeric value.")
'                    Return
'                End If

'                ' Validate Opening Stock
'                Dim openingStockValue As Decimal
'                If Not Decimal.TryParse(Opening_Stock.Text.Trim(), openingStockValue) AndAlso Opening_Stock.Text.Trim() <> "" Then
'                    MessageBox.Show("Opening Stock must be a numeric value.")
'                    Return
'                End If

'                ' Validate MRP
'                Dim mrpValue As Decimal
'                If Not Decimal.TryParse(MRP.Text.Trim(), mrpValue) AndAlso MRP.Text.Trim() <> "" Then
'                    MessageBox.Show("MRP must be a numeric value.")
'                    Return
'                End If
'                ' Check if the data exists in the ItemDetail table

'                ' Data doesn't exist in ItemDetail table, treat it as a new item and insert
'                ModifyItemDetail()
'                    MessageBox.Show("Item modified successfully.")
'                    ClearFields()

'            Catch ex As Exception
'                MessageBox.Show("Error modifying data: " & ex.Message)
'            End Try
'        End If

'    End Sub




'    Private Sub ModifyItemDetail()
'        ' Update data in ItemDetail table
'        Dim query As String = "UPDATE ItemDetail SET Godown = @Godown, Pakage = @Pakage, Unit = @Unit, Opening_Stock = @Opening_Stock, Closing_Stock = @Closing_Stock, MRP = @MRP, GST = @GST WHERE ItemName = @ItemName AND Batch = @Batch AND Godown = @Godown AND Pakage = @Pakage"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                ' Set parameter values
'                command.Parameters.AddWithValue("@ItemName", ItemName.Text.Trim())
'                command.Parameters.AddWithValue("@Batch", Batch.Text.Trim())
'                command.Parameters.AddWithValue("@Godown", Godown.Text.Trim())
'                command.Parameters.AddWithValue("@Pakage", Pakage.Text.Trim())
'                command.Parameters.AddWithValue("@Unit", Unit.Text.Trim())
'                command.Parameters.AddWithValue("@Opening_Stock", Opening_Stock.Text.Trim())
'                command.Parameters.AddWithValue("@Closing_Stock", Closing_Stock.Text.Trim())
'                command.Parameters.AddWithValue("@MRP", MRP.Text.Trim())
'                command.Parameters.AddWithValue("@GST", GST.Text.Trim())

'                ' Execute the SQL command
'                command.ExecuteNonQuery()
'            End Using
'        End Using
'    End Sub

'    Private Sub SaveItemDetail()
'        ' Retrieve the master_id from the ItemMaster table based on the selected ItemName
'        Dim masterId As Integer = GetMasterId(ItemName.Text.Trim())

'        ' Insert data into ItemDetail table
'        Dim query As String = "INSERT INTO ItemDetail (ItemName, Batch, Godown, Pakage, Unit, Opening_Stock, Closing_Stock, MRP, GST, master_id) " &
'                          "VALUES (@ItemName, @Batch, @Godown, @Pakage, @Unit, @Opening_Stock,  @Opening_Stock, @MRP, @GST, @master_id)"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                ' Set parameter values
'                command.Parameters.AddWithValue("@ItemName", ItemName.Text.Trim())
'                command.Parameters.AddWithValue("@Batch", Batch.Text.Trim())
'                command.Parameters.AddWithValue("@Godown", Godown.Text.Trim())
'                command.Parameters.AddWithValue("@Pakage", Pakage.Text.Trim())
'                command.Parameters.AddWithValue("@Unit", Unit.Text.Trim())
'                command.Parameters.AddWithValue("@Opening_Stock", Opening_Stock.Text.Trim())
'                command.Parameters.AddWithValue(" @Opening_Stock", Closing_Stock.Text.Trim())
'                command.Parameters.AddWithValue("@MRP", MRP.Text.Trim())
'                command.Parameters.AddWithValue("@GST", GST.Text.Trim())

'                ' If master_id is found, use it; otherwise, insert NULL
'                If masterId <> -1 Then
'                    command.Parameters.AddWithValue("@master_id", masterId)
'                Else
'                    command.Parameters.AddWithValue("@master_id", DBNull.Value)
'                End If

'                ' Execute the SQL command
'                command.ExecuteNonQuery()
'            End Using
'        End Using
'    End Sub

'    Private Sub Unit_SelectedIndexChanged(sender As Object, e As EventArgs) Handles Unit.SelectedIndexChanged

'    End Sub


'    Private Sub LoadItemsIntoListBox2()
'        Try
'            ' Clear the list box items
'            ListBox2.Items.Clear()

'            ' Define your SQL query to fetch items for ListBox2
'            Dim query As String = "SELECT id.ItemName, id.Batch, id.Godown, id.Pakage, id.Unit, id.Opening_Stock, id.Closing_Stock, id.MRP, id.GST " &
'                              "FROM ItemDetail id " &
'                              "INNER JOIN Itemmaster im ON id.master_id = im.master_id " &
'                              "INNER JOIN MfrMaster mm ON im.mfr_id = mm.mfr_Id " &
'                              "INNER JOIN ItemtypeMaster itm ON im.item_id = itm.item_id"

'            ' Create a SqlConnection object
'            Using connection As New SqlConnection(connectionString)
'                ' Create a SqlCommand object with the query and connection
'                Using command As New SqlCommand(query, connection)
'                    ' Open the connection
'                    connection.Open()

'                    ' Execute the SQL command and retrieve the items
'                    Using reader As SqlDataReader = command.ExecuteReader()
'                        While reader.Read()
'                            ' Construct the item string with details
'                            Dim itemName As String = reader("ItemName").ToString()
'                            Dim batch As String = reader("Batch").ToString()
'                            Dim godown As String = reader("Godown").ToString()
'                            Dim pakage As String = reader("Pakage").ToString()
'                            Dim unit As String = reader("Unit").ToString()
'                            Dim openingStock As String = reader("Opening_Stock").ToString()
'                            Dim closingStock As String = reader("Closing_Stock").ToString()
'                            Dim mrp As String = reader("MRP").ToString()
'                            Dim gst As String = reader("GST").ToString()
'                            Save.Visible = False
'                            ' Create the item string
'                            Dim itemString As String = $"{itemName} : {batch} : {godown} : {pakage} : {unit} : {openingStock} : {closingStock} : {mrp} : {gst}"

'                            ' Add the item to ListBox2
'                            ListBox2.Items.Add(itemString)
'                        End While
'                    End Using
'                End Using
'            End Using
'        Catch ex As Exception
'            MessageBox.Show("Error loading items into ListBox2: " & ex.Message)
'        End Try
'    End Sub

'    Private Sub ListBox2_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox2.KeyDown
'        If e.KeyCode = Keys.Enter Then
'            ' Check if an item is selected in the list box
'            If ListBox2.SelectedIndex <> -1 Then
'                ' Get the selected item from ListBox2
'                Dim selectedItem As String = ListBox2.SelectedItem.ToString()

'                ' Split the selected item string to extract individual details
'                Dim selectedItemDetails As String() = selectedItem.Split(":"c)

'                ' Check if the selected item has enough details
'                If selectedItemDetails.Length >= 9 Then
'                    ' Fill the fields in the ItemDetail form with the selected item details
'                    ItemName.Text = selectedItemDetails(0).Trim()
'                    Batch.Text = selectedItemDetails(1).Trim()
'                    Godown.Text = selectedItemDetails(2).Trim()
'                    Pakage.Text = selectedItemDetails(3).Trim()
'                    Unit.Text = selectedItemDetails(4).Trim()
'                    Opening_Stock.Text = selectedItemDetails(5).Trim()
'                    Closing_Stock.Text = selectedItemDetails(6).Trim()
'                    MRP.Text = selectedItemDetails(7).Trim()
'                    GST.Text = selectedItemDetails(8).Trim()
'                    ListBox1.Visible = False
'                    Save.Visible = False
'                    ' Fetch and set Manufacturer and ItemType
'                    Try
'                        Dim itemName As String = selectedItemDetails(0).Trim()
'                        ' Define your SQL query to fetch Manufacturer and ItemType for the selected item
'                        Dim query As String = "SELECT mm.Mfrname, itm.Itemtype " &
'                                              "FROM ItemDetail id " &
'                                              "INNER JOIN Itemmaster im ON id.master_id = im.master_id " &
'                                              "INNER JOIN MfrMaster mm ON im.mfr_id = mm.mfr_Id " &
'                                              "INNER JOIN ItemtypeMaster itm ON im.item_id = itm.item_id " &
'                                              "WHERE id.ItemName = @ItemName"

'                        ' Create a SqlConnection object
'                        Using connection As New SqlConnection(connectionString)
'                            ' Create a SqlCommand object with the query and connection
'                            Using command As New SqlCommand(query, connection)
'                                ' Set the parameter value for the item name
'                                command.Parameters.AddWithValue("@ItemName", itemName)

'                                ' Open the connection
'                                connection.Open()

'                                ' Execute the SQL command and retrieve the Manufacturer and ItemType
'                                Using reader As SqlDataReader = command.ExecuteReader()
'                                    If reader.Read() Then
'                                        ' Fill the Manufacturer and ItemType fields
'                                        Manufature1.Text = reader("Mfrname").ToString().Trim()
'                                        Itemtype.Text = reader("Itemtype").ToString().Trim()
'                                    End If
'                                End Using
'                            End Using
'                        End Using
'                    Catch ex As Exception
'                        MessageBox.Show("Error fetching Manufacturer and ItemType: " & ex.Message)
'                    End Try

'                    ' Hide ListBox2
'                    ListBox2.Visible = False

'                    ' Disable controls if needed
'                    Manufature1.Enabled = False
'                    Itemtype.Enabled = False
'                    Godown.Enabled = False
'                    Pakage.Enabled = False
'                    Unit.Enabled = False
'                Else
'                    MessageBox.Show("Error: Incomplete item details.")
'                End If
'            End If
'        End If
'    End Sub
'    Private Sub ListBox2_MouseDoubleClick(sender As Object, e As MouseEventArgs) Handles ListBox2.MouseDoubleClick
'        ' Check if an item is selected in the list box
'        If ListBox2.SelectedIndex <> -1 Then
'            ' Get the selected item from ListBox2
'            Dim selectedItem As String = ListBox2.SelectedItem.ToString()

'            ' Split the selected item string to extract individual details
'            Dim selectedItemDetails As String() = selectedItem.Split(":"c)

'            ' Check if the selected item has enough details
'            If selectedItemDetails.Length >= 9 Then
'                ' Fill the fields in the ItemDetail form with the selected item details
'                ItemName.Text = selectedItemDetails(0).Trim()
'                Batch.Text = selectedItemDetails(1).Trim()
'                Godown.Text = selectedItemDetails(2).Trim()
'                Pakage.Text = selectedItemDetails(3).Trim()
'                Unit.Text = selectedItemDetails(4).Trim()
'                Opening_Stock.Text = selectedItemDetails(5).Trim()
'                Closing_Stock.Text = selectedItemDetails(6).Trim()
'                MRP.Text = selectedItemDetails(7).Trim()
'                GST.Text = selectedItemDetails(8).Trim()
'                ListBox1.Visible = False
'                ' Fetch and set Manufacturer and ItemType
'                Try
'                    Dim itemName As String = selectedItemDetails(0).Trim()
'                    ' Define your SQL query to fetch Manufacturer and ItemType for the selected item
'                    Dim query As String = "SELECT mm.Mfrname, itm.Itemtype " &
'                                      "FROM ItemDetail id " &
'                                      "INNER JOIN Itemmaster im ON id.master_id = im.master_id " &
'                                      "INNER JOIN MfrMaster mm ON im.mfr_id = mm.mfr_Id " &
'                                      "INNER JOIN ItemtypeMaster itm ON im.item_id = itm.item_id " &
'                                      "WHERE id.ItemName = @ItemName"

'                    ' Create a SqlConnection object
'                    Using connection As New SqlConnection(connectionString)
'                        ' Create a SqlCommand object with the query and connection
'                        Using command As New SqlCommand(query, connection)
'                            ' Set the parameter value for the item name
'                            command.Parameters.AddWithValue("@ItemName", itemName)

'                            ' Open the connection
'                            connection.Open()

'                            ' Execute the SQL command and retrieve the Manufacturer and ItemType
'                            Using reader As SqlDataReader = command.ExecuteReader()
'                                If reader.Read() Then
'                                    ' Fill the Manufacturer and ItemType fields
'                                    Manufature1.Text = reader("Mfrname").ToString().Trim()
'                                    Itemtype.Text = reader("Itemtype").ToString().Trim()
'                                End If
'                            End Using
'                        End Using
'                    End Using
'                Catch ex As Exception
'                    MessageBox.Show("Error fetching Manufacturer and ItemType: " & ex.Message)
'                    ClearFields()
'                End Try

'                ' Hide ListBox2
'                ListBox2.Visible = False

'                ' Disable controls if needed
'                Manufature1.Enabled = False
'                Itemtype.Enabled = False
'                Godown.Enabled = False
'                Pakage.Enabled = False
'                Unit.Enabled = False
'            Else
'                MessageBox.Show("Error: Incomplete item details.")
'                ClearFields()
'            End If
'        End If
'    End Sub
'    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
'        If Manufature1.Text.Trim() = "" Then
'            Try
'                ' Call the method to load items into ListBox2
'                LoadItemsIntoListBox2()

'                ' Make ListBox2 visible
'                ListBox2.Visible = True

'                If ListBox2.Visible = False Then
'                    ' Check if ListBox2 is empty
'                    If ListBox2.Items.Count = 0 Then
'                        MessageBox.Show("The list is empty. Please add items before modifying.")
'                        ListBox2.Visible = False ' Hide ListBox2 if it's empty
'                        Return
'                    End If
'                    ' Check if required fields are empty
'                    If ItemName.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Item Name.")
'                        Return
'                    End If

'                    If Batch.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Batch.")
'                        Return
'                    End If

'                    If Godown.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Godown.")
'                        Return
'                    End If

'                    If Pakage.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Pakage.")
'                        Return
'                    End If

'                    If DataExistsInItemDetailTable(ItemName.Text.Trim(), Batch.Text.Trim()) Then
'                        ' Data exists in ItemDetail table, proceed with deletion
'                        DeleteItemDetail(ItemName.Text.Trim(), Batch.Text.Trim())
'                        MessageBox.Show("Item deleted successfully ")
'                        ClearFields()
'                    Else
'                        MessageBox.Show("No matching item found in ItemDetail table.")
'                        ClearFields()
'                    End If
'                End If
'            Catch ex As Exception
'                MessageBox.Show("Error deleting item: " & ex.Message)
'                ClearFields()
'            End Try
'        Else
'            Try
'                ' Call the method to load items into ListBox2

'                ' Check if required fields are empty
'                If ItemName.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Item Name.")
'                        Return
'                    End If

'                    If Batch.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Batch.")
'                        Return
'                    End If

'                    If Godown.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Godown.")
'                        Return
'                    End If

'                    If Pakage.Text.Trim() = "" Then
'                        MessageBox.Show("Please enter Pakage.")
'                        Return
'                    End If

'                    If DataExistsInItemDetailTable(ItemName.Text.Trim(), Batch.Text.Trim()) Then
'                        ' Data exists in ItemDetail table, proceed with deletion
'                        DeleteItemDetail(ItemName.Text.Trim(), Batch.Text.Trim())
'                        MessageBox.Show("Item deleted successfully ")
'                        ClearFields()
'                    Else
'                        MessageBox.Show("No matching item found in ItemDetail table.")
'                        ClearFields()
'                    End If

'            Catch ex As Exception
'                MessageBox.Show("Error deleting item: " & ex.Message)
'                ClearFields()
'            End Try
'        End If
'    End Sub


'    Private Sub DeleteItemDetail(itemName As String, batch As String)
'        Dim query As String = "DELETE FROM ItemDetail WHERE ItemName = @ItemName AND Batch = @Batch"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                ' Set parameter values
'                command.Parameters.AddWithValue("@ItemName", itemName)
'                command.Parameters.AddWithValue("@Batch", batch)

'                ' Execute the SQL command to delete the item
'                command.ExecuteNonQuery()
'            End Using
'        End Using
'    End Sub



'    Private Function DataExistsInItemDetailTable(itemName As String, batch As String) As Boolean
'        Dim query As String = "SELECT COUNT(*) FROM ItemDetail WHERE ItemName = @ItemName AND Batch = @Batch"

'        Using connection As New SqlConnection(connectionString)
'            Using command As New SqlCommand(query, connection)
'                connection.Open()

'                ' Set parameter values
'                command.Parameters.AddWithValue("@ItemName", itemName)
'                command.Parameters.AddWithValue("@Batch", batch)

'                ' Execute the query to check if data exists
'                Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

'                ' Return True if data exists, False otherwise
'                Return count > 0
'            End Using
'        End Using
'    End Function
'    Private Sub Opening_Stock_TextChanged(sender As Object, e As EventArgs) Handles Opening_Stock.TextChanged
'        Closing_Stock.Text = Opening_Stock.Text
'    End Sub

'    Private Sub Close_Click(sender As Object, e As EventArgs) Handles Close.Click

'        Me.Dispose()
'    End Sub
'End Class