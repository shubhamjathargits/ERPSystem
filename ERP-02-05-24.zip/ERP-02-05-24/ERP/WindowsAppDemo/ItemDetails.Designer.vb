﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ItemDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.ItemNameID = New System.Windows.Forms.TextBox()
        Me.ItemName = New System.Windows.Forms.TextBox()
        Me.Batch = New System.Windows.Forms.TextBox()
        Me.Godown = New System.Windows.Forms.TextBox()
        Me.Pakage = New System.Windows.Forms.TextBox()
        Me.Opening_Stock = New System.Windows.Forms.TextBox()
        Me.Closing_Stock = New System.Windows.Forms.TextBox()
        Me.MRP = New System.Windows.Forms.TextBox()
        Me.GST = New System.Windows.Forms.TextBox()
        Me.MfrMasterBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DemoItemDataSet7 = New WindowsAppDemo.DemoItemDataSet7()
        Me.ItemtypeMasterBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DemoItemDataSet8 = New WindowsAppDemo.DemoItemDataSet8()
        Me.Save = New System.Windows.Forms.Button()
        Me.Clear = New System.Windows.Forms.Button()
        Me.MfrMasterTableAdapter = New WindowsAppDemo.DemoItemDataSet7TableAdapters.MfrMasterTableAdapter()
        Me.ItemtypeMasterTableAdapter = New WindowsAppDemo.DemoItemDataSet8TableAdapters.ItemtypeMasterTableAdapter()
        Me.Manufature1 = New System.Windows.Forms.ComboBox()
        Me.Itemtype = New System.Windows.Forms.ComboBox()
        Me.Delete = New System.Windows.Forms.Button()
        Me.Modify = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.Unit = New System.Windows.Forms.ComboBox()
        Me.UnitBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DemoItemDataSet9 = New WindowsAppDemo.DemoItemDataSet9()
        Me.UnitTableAdapter = New WindowsAppDemo.DemoItemDataSet9TableAdapters.UnitTableAdapter()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        Me.DemoItemDataSet10 = New WindowsAppDemo.DemoItemDataSet10()
        Me.ItemDetailBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ItemDetailTableAdapter = New WindowsAppDemo.DemoItemDataSet10TableAdapters.ItemDetailTableAdapter()
        Me.Close = New System.Windows.Forms.Button()
        CType(Me.MfrMasterBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ItemtypeMasterBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.UnitBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet9, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DemoItemDataSet10, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ItemDetailBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.InactiveCaptionText
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.ForeColor = System.Drawing.SystemColors.MenuBar
        Me.TextBox1.Location = New System.Drawing.Point(-2, 18)
        Me.TextBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(1202, 35)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "ItemDetails"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(116, 185)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(104, 22)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Item Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(111, 232)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(110, 22)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Manufature"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(140, 277)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(85, 22)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Itemtype"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(166, 323)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 22)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Batch"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(142, 369)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(83, 22)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Godown"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(148, 417)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(77, 22)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Pakage"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(698, 422)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(46, 22)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Unit"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(603, 285)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(141, 22)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Opening Stock"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(612, 334)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(133, 22)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Closing Stock"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(690, 375)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(52, 22)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "MRP"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(684, 240)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(68, 22)
        Me.Label13.TabIndex = 13
        Me.Label13.Text = "GST%"
        '
        'ItemNameID
        '
        Me.ItemNameID.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemNameID.Location = New System.Drawing.Point(267, 125)
        Me.ItemNameID.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ItemNameID.Name = "ItemNameID"
        Me.ItemNameID.Size = New System.Drawing.Size(278, 28)
        Me.ItemNameID.TabIndex = 15
        Me.ItemNameID.Visible = False
        '
        'ItemName
        '
        Me.ItemName.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ItemName.Location = New System.Drawing.Point(267, 180)
        Me.ItemName.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ItemName.Name = "ItemName"
        Me.ItemName.Size = New System.Drawing.Size(278, 28)
        Me.ItemName.TabIndex = 16
        '
        'Batch
        '
        Me.Batch.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Batch.Location = New System.Drawing.Point(267, 318)
        Me.Batch.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Batch.Name = "Batch"
        Me.Batch.Size = New System.Drawing.Size(278, 28)
        Me.Batch.TabIndex = 17
        '
        'Godown
        '
        Me.Godown.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Godown.Location = New System.Drawing.Point(267, 365)
        Me.Godown.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Godown.Name = "Godown"
        Me.Godown.Size = New System.Drawing.Size(278, 28)
        Me.Godown.TabIndex = 18
        '
        'Pakage
        '
        Me.Pakage.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pakage.Location = New System.Drawing.Point(266, 412)
        Me.Pakage.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Pakage.Name = "Pakage"
        Me.Pakage.Size = New System.Drawing.Size(278, 28)
        Me.Pakage.TabIndex = 19
        '
        'Opening_Stock
        '
        Me.Opening_Stock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Opening_Stock.Location = New System.Drawing.Point(782, 280)
        Me.Opening_Stock.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Opening_Stock.Name = "Opening_Stock"
        Me.Opening_Stock.Size = New System.Drawing.Size(278, 28)
        Me.Opening_Stock.TabIndex = 21
        '
        'Closing_Stock
        '
        Me.Closing_Stock.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Closing_Stock.ForeColor = System.Drawing.SystemColors.GrayText
        Me.Closing_Stock.Location = New System.Drawing.Point(782, 325)
        Me.Closing_Stock.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Closing_Stock.Name = "Closing_Stock"
        Me.Closing_Stock.Size = New System.Drawing.Size(278, 28)
        Me.Closing_Stock.TabIndex = 22
        '
        'MRP
        '
        Me.MRP.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MRP.Location = New System.Drawing.Point(782, 371)
        Me.MRP.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.MRP.Name = "MRP"
        Me.MRP.Size = New System.Drawing.Size(278, 28)
        Me.MRP.TabIndex = 23
        '
        'GST
        '
        Me.GST.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GST.Location = New System.Drawing.Point(782, 235)
        Me.GST.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GST.Name = "GST"
        Me.GST.Size = New System.Drawing.Size(278, 28)
        Me.GST.TabIndex = 24
        '
        'MfrMasterBindingSource
        '
        Me.MfrMasterBindingSource.DataMember = "MfrMaster"
        Me.MfrMasterBindingSource.DataSource = Me.DemoItemDataSet7
        '
        'DemoItemDataSet7
        '
        Me.DemoItemDataSet7.DataSetName = "DemoItemDataSet7"
        Me.DemoItemDataSet7.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ItemtypeMasterBindingSource
        '
        Me.ItemtypeMasterBindingSource.DataMember = "ItemtypeMaster"
        Me.ItemtypeMasterBindingSource.DataSource = Me.DemoItemDataSet8
        '
        'DemoItemDataSet8
        '
        Me.DemoItemDataSet8.DataSetName = "DemoItemDataSet8"
        Me.DemoItemDataSet8.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'Save
        '
        Me.Save.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Save.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Save.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Save.Location = New System.Drawing.Point(264, 503)
        Me.Save.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Save.Name = "Save"
        Me.Save.Size = New System.Drawing.Size(112, 54)
        Me.Save.TabIndex = 27
        Me.Save.Text = "Save"
        Me.Save.UseVisualStyleBackColor = False
        '
        'Clear
        '
        Me.Clear.BackColor = System.Drawing.Color.DodgerBlue
        Me.Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Clear.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Clear.Location = New System.Drawing.Point(544, 503)
        Me.Clear.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Clear.Name = "Clear"
        Me.Clear.Size = New System.Drawing.Size(112, 54)
        Me.Clear.TabIndex = 28
        Me.Clear.Text = "Clear"
        Me.Clear.UseVisualStyleBackColor = False
        '
        'MfrMasterTableAdapter
        '
        Me.MfrMasterTableAdapter.ClearBeforeFill = True
        '
        'ItemtypeMasterTableAdapter
        '
        Me.ItemtypeMasterTableAdapter.ClearBeforeFill = True
        '
        'Manufature1
        '
        Me.Manufature1.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.MfrMasterBindingSource, "Mfrname", True))
        Me.Manufature1.FormattingEnabled = True
        Me.Manufature1.Location = New System.Drawing.Point(267, 231)
        Me.Manufature1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Manufature1.Name = "Manufature1"
        Me.Manufature1.Size = New System.Drawing.Size(280, 28)
        Me.Manufature1.TabIndex = 31
        '
        'Itemtype
        '
        Me.Itemtype.FormattingEnabled = True
        Me.Itemtype.Location = New System.Drawing.Point(267, 275)
        Me.Itemtype.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Itemtype.Name = "Itemtype"
        Me.Itemtype.Size = New System.Drawing.Size(280, 28)
        Me.Itemtype.TabIndex = 32
        '
        'Delete
        '
        Me.Delete.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Delete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Delete.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Delete.Location = New System.Drawing.Point(688, 503)
        Me.Delete.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(112, 54)
        Me.Delete.TabIndex = 33
        Me.Delete.Text = "Delete"
        Me.Delete.UseVisualStyleBackColor = False
        '
        'Modify
        '
        Me.Modify.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Modify.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Modify.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Modify.Location = New System.Drawing.Point(402, 503)
        Me.Modify.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Modify.Name = "Modify"
        Me.Modify.Size = New System.Drawing.Size(112, 54)
        Me.Modify.TabIndex = 34
        Me.Modify.Text = "Modify"
        Me.Modify.UseVisualStyleBackColor = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.ItemHeight = 20
        Me.ListBox1.Location = New System.Drawing.Point(266, 220)
        Me.ListBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(320, 124)
        Me.ListBox1.TabIndex = 35
        Me.ListBox1.Visible = False
        '
        'Unit
        '
        Me.Unit.DataBindings.Add(New System.Windows.Forms.Binding("SelectedValue", Me.MfrMasterBindingSource, "Mfrname", True))
        Me.Unit.DataSource = Me.UnitBindingSource
        Me.Unit.DisplayMember = "Units"
        Me.Unit.FormattingEnabled = True
        Me.Unit.Location = New System.Drawing.Point(780, 415)
        Me.Unit.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Unit.Name = "Unit"
        Me.Unit.Size = New System.Drawing.Size(280, 28)
        Me.Unit.TabIndex = 36
        '
        'UnitBindingSource
        '
        Me.UnitBindingSource.DataMember = "Unit"
        Me.UnitBindingSource.DataSource = Me.DemoItemDataSet9
        '
        'DemoItemDataSet9
        '
        Me.DemoItemDataSet9.DataSetName = "DemoItemDataSet9"
        Me.DemoItemDataSet9.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'UnitTableAdapter
        '
        Me.UnitTableAdapter.ClearBeforeFill = True
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.ItemHeight = 20
        Me.ListBox2.Location = New System.Drawing.Point(402, 89)
        Me.ListBox2.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(690, 264)
        Me.ListBox2.TabIndex = 37
        Me.ListBox2.Visible = False
        '
        'DemoItemDataSet10
        '
        Me.DemoItemDataSet10.DataSetName = "DemoItemDataSet10"
        Me.DemoItemDataSet10.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ItemDetailBindingSource
        '
        Me.ItemDetailBindingSource.DataMember = "ItemDetail"
        Me.ItemDetailBindingSource.DataSource = Me.DemoItemDataSet10
        '
        'ItemDetailTableAdapter
        '
        Me.ItemDetailTableAdapter.ClearBeforeFill = True
        '
        'Close
        '
        Me.Close.BackColor = System.Drawing.Color.Purple
        Me.Close.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Close.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Close.Location = New System.Drawing.Point(840, 503)
        Me.Close.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Close.Name = "Close"
        Me.Close.Size = New System.Drawing.Size(112, 54)
        Me.Close.TabIndex = 38
        Me.Close.Text = "Close"
        Me.Close.UseVisualStyleBackColor = False
        '
        'ItemDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.Close)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Unit)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Modify)
        Me.Controls.Add(Me.Delete)
        Me.Controls.Add(Me.Itemtype)
        Me.Controls.Add(Me.Manufature1)
        Me.Controls.Add(Me.Clear)
        Me.Controls.Add(Me.Save)
        Me.Controls.Add(Me.GST)
        Me.Controls.Add(Me.MRP)
        Me.Controls.Add(Me.Closing_Stock)
        Me.Controls.Add(Me.Opening_Stock)
        Me.Controls.Add(Me.Pakage)
        Me.Controls.Add(Me.Godown)
        Me.Controls.Add(Me.Batch)
        Me.Controls.Add(Me.ItemName)
        Me.Controls.Add(Me.ItemNameID)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "ItemDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ItemDetails"
        CType(Me.MfrMasterBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ItemtypeMasterBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.UnitBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet9, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DemoItemDataSet10, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ItemDetailBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents ItemNameID As TextBox
    Friend WithEvents ItemName As TextBox
    Friend WithEvents Batch As TextBox
    Friend WithEvents Godown As TextBox
    Friend WithEvents Pakage As TextBox
    Friend WithEvents Opening_Stock As TextBox
    Friend WithEvents Closing_Stock As TextBox
    Friend WithEvents MRP As TextBox
    Friend WithEvents GST As TextBox
    Friend WithEvents Save As Button
    Friend WithEvents Clear As Button

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub
    Friend WithEvents DemoItemDataSet7 As DemoItemDataSet7
    Friend WithEvents MfrMasterBindingSource As BindingSource
    Friend WithEvents MfrMasterTableAdapter As DemoItemDataSet7TableAdapters.MfrMasterTableAdapter
    Friend WithEvents DemoItemDataSet8 As DemoItemDataSet8
    Friend WithEvents ItemtypeMasterBindingSource As BindingSource
    Friend WithEvents ItemtypeMasterTableAdapter As DemoItemDataSet8TableAdapters.ItemtypeMasterTableAdapter
    Friend WithEvents Manufature1 As ComboBox
    Friend WithEvents Itemtype As ComboBox
    Friend WithEvents Delete As Button
    Friend WithEvents Modify As Button
    Friend WithEvents ListBox1 As ListBox
    Friend WithEvents Unit As ComboBox
    Friend WithEvents DemoItemDataSet9 As DemoItemDataSet9
    Friend WithEvents UnitBindingSource As BindingSource
    Friend WithEvents UnitTableAdapter As DemoItemDataSet9TableAdapters.UnitTableAdapter
    Friend WithEvents ListBox2 As ListBox
    Friend WithEvents DemoItemDataSet10 As DemoItemDataSet10
    Friend WithEvents ItemDetailBindingSource As BindingSource
    Friend WithEvents ItemDetailTableAdapter As DemoItemDataSet10TableAdapters.ItemDetailTableAdapter
    Friend WithEvents Close As Button
End Class
