﻿Imports System.Data.SqlClient

Public Class ItemMaster
   
    ' Define your connection string
    Dim connectionString As String = "Data Source=DESKTOP-HL63BC4\SQLEXPRESS;Initial Catalog=DemoItem;Integrated Security=True"
    Public Sub New()
        ' This call is required by the designer.
        InitializeComponent()

        ' Add KeyDown event handlers programmatically
        AddHandler ItemName.KeyDown, AddressOf ItemName_KeyDown
        AddHandler Description.KeyDown, AddressOf Description_KeyDown
        AddHandler Godown.KeyDown, AddressOf Godown_KeyDown
        AddHandler Pakage.KeyDown, AddressOf Pakage_KeyDown
        AddHandler Unit.KeyDown, AddressOf Unit_KeyDown

        AddHandler Manufature.KeyDown, AddressOf Manufature_KeyDown
        AddHandler Iteamtype.KeyDown, AddressOf Iteamtype_KeyDown
    End Sub
    Private Sub ItemMaster_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Load data into ComboBoxes when the form loads
        LoadManufacturers()
        LoadItemTypes()
        ItemID.Enabled = False
        Manufature.SelectedIndex = -1
        Iteamtype.SelectedIndex = -1
        Manufature.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        Manufature.AutoCompleteSource = AutoCompleteSource.ListItems
        Iteamtype.AutoCompleteMode = AutoCompleteMode.SuggestAppend
        Iteamtype.AutoCompleteSource = AutoCompleteSource.ListItems
    End Sub

    Private Sub SaveItem()
        ' Check if the item already exists in the ItemMaster table
        If ItemExists(ItemName.Text, Manufature.Text, Iteamtype.Text) Then
            MessageBox.Show("Item already Exist.")
            Return
        End If


        ' Check if the ItemName field is empty
        ' Check if the ItemName field is empty
        If String.IsNullOrWhiteSpace(ItemName.Text) Then
            MessageBox.Show("Please Enter the ItemName.")
            Return
        End If

        ' Check if the Manufacturer field is empty
        If Manufature.SelectedIndex = -1 Then
            MessageBox.Show("Please select an Manufacturer.")
            Return
        End If

        ' Check if the ItemType field is empty
        If Iteamtype.SelectedIndex = -1 Then
            MessageBox.Show("Please select an ItemType.")
            Return
        End If

        ' Check if the Godown field is empty
        If String.IsNullOrWhiteSpace(Godown.Text) Then
            MessageBox.Show("Please Enter the Godown .")
            Return
        End If

        If Pakage.Text.Trim() = "" Then
            MessageBox.Show("Please enter Pakage.")
            Return
        End If

        ' Define your SQL query to insert data into the ItemMaster table
        Dim query As String = "INSERT INTO ItemMaster (ItemName, Description, Godown, pakage, unit, mfr_id, item_id) VALUES (@ItemName, @Description, @Godown, @pakage, @unit, @mfr_id, @item_id)"

        ' Create a SqlConnection object
        Using connection As New SqlConnection(connectionString)
            ' Create a SqlCommand object with the query and connection
            Using command As New SqlCommand(query, connection)
                ' Set the parameter values for the query
                command.Parameters.AddWithValue("@ItemName", ItemName.Text)
                command.Parameters.AddWithValue("@Description", Description.Text)
                command.Parameters.AddWithValue("@Godown", Godown.Text)
                command.Parameters.AddWithValue("@Pakage", Pakage.Text)
                command.Parameters.AddWithValue("@Unit", Unit.Text) ' Keep unit as string

                ' Get mfr_id based on the selected manufacturer name
                Dim mfrId As Integer = GetManufacturerId(Manufature.Text)
                command.Parameters.AddWithValue("@mfr_id", mfrId)

                ' Get item_id based on the selected item type
                Dim itemId As Integer = GetItemTypeId(Iteamtype.Text)
                command.Parameters.AddWithValue("@item_id", itemId)

                Try
                    ' Open the connection
                    connection.Open()
                    ' Execute the SQL command
                    command.ExecuteNonQuery()
                    MessageBox.Show("Item saved successfully.")
                    ClearForm()
                Catch ex As Exception
                    MessageBox.Show("Error saving item: " & ex.Message)
                End Try
            End Using
        End Using
    End Sub


    Private Function ItemExists(itemName As String, manufacturer As String, itemType As String) As Boolean
        ' Define your SQL query to check if the item exists
        Dim query As String = "SELECT COUNT(*) FROM ItemMaster " &
                          "INNER JOIN MfrMaster ON ItemMaster.mfr_id = MfrMaster.mfr_Id " &
                          "INNER JOIN ItemtypeMaster ON ItemMaster.item_id = ItemtypeMaster.item_id " &
                          "WHERE ItemName = @ItemName AND Mfrname = @Manufacturer AND Itemtype = @ItemType"

        ' Create a SqlConnection object
        Using connection As New SqlConnection(connectionString)
            ' Create a SqlCommand object with the query and connection
            Using command As New SqlCommand(query, connection)
                ' Set the parameter values for the query
                command.Parameters.AddWithValue("@ItemName", itemName)
                command.Parameters.AddWithValue("@Manufacturer", manufacturer)
                command.Parameters.AddWithValue("@ItemType", itemType)

                ' Open the connection
                connection.Open()

                ' Execute the SQL command and retrieve the count
                Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

                ' If count > 0, it means the item already exists
                Return count > 0
            End Using
        End Using
    End Function


    Private Function GetManufacturerId(manufacturerName As String) As Integer
        Dim query As String = "SELECT mfr_Id FROM MfrMaster WHERE Mfrname = @ManufacturerName"
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@ManufacturerName", manufacturerName)
                connection.Open()
                Dim result As Object = command.ExecuteScalar()
                If result IsNot Nothing AndAlso Not DBNull.Value.Equals(result) Then
                    Return Convert.ToInt32(result)
                Else
                    ' Return -1 if manufacturer is not found
                    Return -1
                End If
            End Using
        End Using
    End Function

    Private Function GetItemTypeId(itemTypeName As String) As Integer
        Dim query As String = "SELECT item_id FROM ItemtypeMaster WHERE Itemtype = @ItemTypeName"
        Using connection As New SqlConnection(connectionString)
            Using command As New SqlCommand(query, connection)
                command.Parameters.AddWithValue("@ItemTypeName", itemTypeName)
                connection.Open()
                Dim result As Object = command.ExecuteScalar()
                If result IsNot Nothing AndAlso Not DBNull.Value.Equals(result) Then
                    Return Convert.ToInt32(result)
                Else
                    ' Return -1 if item type is not found
                    Return -1
                End If
            End Using
        End Using
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        ' If all validations pass, proceed with saving the item
        SaveItem()

    End Sub


    Private Sub LoadManufacturers()
        Try
            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Define your SQL query to select manufacturers
                Dim query As String = "SELECT Mfrname FROM MfrMaster"

                ' Create a SqlDataAdapter to fetch data
                Using adapter As New SqlDataAdapter(query, connection)
                    ' Create a DataTable to store results
                    Dim dt As New DataTable()

                    ' Fill the DataTable with data from database
                    adapter.Fill(dt)

                    ' Set up ComboBox with DataTable
                    Manufature.DataSource = dt
                    Manufature.DisplayMember = "Mfrname"
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading manufacturers: " & ex.Message)
        End Try
    End Sub

    Private Sub LoadItemTypes()
        Try
            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Define your SQL query to select item types
                Dim query As String = "SELECT Itemtype FROM ItemtypeMaster"

                ' Create a SqlDataAdapter to fetch data
                Using adapter As New SqlDataAdapter(query, connection)
                    ' Create a DataTable to store results
                    Dim dt As New DataTable()

                    ' Fill the DataTable with data from database
                    adapter.Fill(dt)

                    ' Set up ComboBox with DataTable
                    Iteamtype.DataSource = dt
                    Iteamtype.DisplayMember = "Itemtype"
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading item types: " & ex.Message)
        End Try
    End Sub
    Private Sub ClearForm()
        ' Clear all the textboxes
        ItemName.Text = ""
        Description.Text = ""
        Godown.Text = ""
        Pakage.Text = ""
        Unit.Text = ""
        Manufature.Text = ""
        Iteamtype.Text = ""
        ItemID.Text = " "
        ' Set the selected index of comboboxes to -1 (none selected)
        Manufature.SelectedIndex = -1
        Iteamtype.SelectedIndex = -1
    End Sub

    Private Sub clear_Click(sender As Object, e As EventArgs) Handles clear.Click
        ClearForm()
        Button1.Visible = True
        Update.Visible = False

    End Sub


    ' Check if an item is selected in the ItemName combobox



    ' Confirm with the user before deleting the item
    Private Sub Delete_Click(sender As Object, e As EventArgs) Handles Delete.Click
        ' Check if an item is selected in the ItemID textbox
        If String.IsNullOrWhiteSpace(ItemID.Text) Then
            MessageBox.Show("Please select an item to delete.")
            Return
        End If

        ' Confirm with the user before deleting the item
        Dim result As DialogResult = MessageBox.Show("Are you sure you want to delete this item?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
        If result = DialogResult.Yes Then
            ' Delete the item from the database
            If DeleteItem(Convert.ToInt32(ItemID.Text)) Then
                MessageBox.Show("Item deleted successfully.")
                ' Clear the form after successful deletion
                Button1.Visible = True
                Update.Visible = False
                ClearForm()
                Manufature.SelectedIndex = -1
                Iteamtype.SelectedIndex = -1
                ' Reload manufacturers and item types
                ' Clear the ItemID TextBox
                ItemID.Text = ""
            Else
                MessageBox.Show("Transaction found Item cannot be deleted")
            End If
        End If
    End Sub



    Private Function DeleteItem(masterId As Integer) As Boolean
        Try
            ' Define your SQL query to delete the item from the database
            Dim query As String = "DELETE FROM Itemmaster WHERE master_id = @MasterId"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter values for the query
                    command.Parameters.AddWithValue("@MasterId", masterId)

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command
                    command.ExecuteNonQuery()

                    ' Return true to indicate successful deletion
                    Return True
                End Using
            End Using
        Catch ex As Exception
            ' If an error occurs, return false
            Return False
        End Try
    End Function

    Private Sub UpdateItem()
        ' Check if the ItemName field is empty
        If String.IsNullOrWhiteSpace(ItemName.Text) Then
            MessageBox.Show("Please Enter the ItemName.")
            Return
        End If

        ' Check if the Manufacturer field is empty


        If Manufature.Text.Trim() = "" Then
            MessageBox.Show("Please select Manufacturer.")
            Return
        End If

        If Iteamtype.Text.Trim() = "" Then
            MessageBox.Show("Please select Item type.")
            Return
        End If
        ' Check if the Godown field is empty
        If String.IsNullOrWhiteSpace(Godown.Text) Then
            MessageBox.Show("Please Enter the Godown .")
            Return
        End If

        ' Continue with the update process...

        ' Retrieve the item type ID based on the selected item type
        Dim itemTypeId As Integer = GetItemTypeId(Iteamtype.Text)

        ' Define your SQL query to update the item in the database
        Dim query As String = "UPDATE Itemmaster SET ItemName = @NewItemName, Description = @Description, Godown = @Godown, pakage = @Pakage, unit = @Unit, mfr_id = @ManufacturerId, item_id = @ItemTypeId WHERE ItemName = @OldItemName"

        ' Create a SqlConnection object
        Using connection As New SqlConnection(connectionString)
            ' Create a SqlCommand object with the query and connection
            Using command As New SqlCommand(query, connection)
                ' Set the parameter values for the query
                command.Parameters.AddWithValue("@NewItemName", ItemName.Text)
                command.Parameters.AddWithValue("@Description", Description.Text)
                command.Parameters.AddWithValue("@Godown", Godown.Text)
                command.Parameters.AddWithValue("@Pakage", Pakage.Text)
                command.Parameters.AddWithValue("@Unit", Unit.Text)

                ' Get the manufacturer ID based on the selected manufacturer name
                Dim manufacturerId As Integer = GetManufacturerId(Manufature.Text)
                command.Parameters.AddWithValue("@ManufacturerId", manufacturerId)

                ' Set the item type ID for the update
                command.Parameters.AddWithValue("@ItemTypeId", itemTypeId)

                ' Set the old item name for updating
                command.Parameters.AddWithValue("@OldItemName", ItemName.Text)

                Try
                    ' Open the connection
                    connection.Open()
                    ' Execute the SQL command
                    command.ExecuteNonQuery()
                    MessageBox.Show("Item updated successfully.")
                    Button1.Visible = True
                    Update.Visible = False
                    Button1.Visible = True
                    Update.Visible = False
                    ClearForm()
                Catch ex As SqlException
                    ' Check if the error is due to the item already existing
                    If ex.Number = 2601 OrElse ex.Number = 2627 Then ' Unique constraint violation
                        MessageBox.Show("Item already exists.")
                    Else
                        MessageBox.Show("Error updating item: " & ex.Message)
                    End If
                End Try
            End Using
        End Using
    End Sub



    Private Function ItemExistsWithDifferentDetails(itemName As String, manufacturer As String, itemType As String) As Boolean
        ' Define your SQL query to check if an item with the same name, manufacturer, and type exists with different details
        Dim query As String = "SELECT COUNT(*) FROM ItemMaster " &
                    "INNER JOIN MfrMaster ON ItemMaster.mfr_id = MfrMaster.mfr_Id " &
                    "INNER JOIN ItemtypeMaster ON ItemMaster.item_id = ItemtypeMaster.item_id " &
                    "WHERE ItemName = @ItemName AND Mfrname = @Manufacturer AND Itemtype = @ItemType " &
                    "AND (ItemMaster.ItemName <> @ItemName OR MfrMaster.Mfrname <> @Manufacturer OR ItemtypeMaster.Itemtype <> @ItemType)"

        ' Create a SqlConnection object
        Using connection As New SqlConnection(connectionString)
            ' Create a SqlCommand object with the query and connection
            Using command As New SqlCommand(query, connection)
                ' Set the parameter values for the query
                command.Parameters.AddWithValue("@ItemName", itemName)
                command.Parameters.AddWithValue("@Manufacturer", manufacturer)
                command.Parameters.AddWithValue("@ItemType", itemType)

                ' Open the connection
                connection.Open()

                ' Execute the SQL command and retrieve the count
                Dim count As Integer = Convert.ToInt32(command.ExecuteScalar())

                ' If count > 0, it means an item with the same name, manufacturer, and type exists with different details
                Return count > 0
            End Using
        End Using
    End Function



    Private Sub ItemName_KeyDown(sender As Object, e As KeyEventArgs) Handles ItemName.KeyDown
        If ListBox1.Visible = True Then
            If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
                ListBox1.Focus()
                e.SuppressKeyPress = True
            End If
        ElseIf ListBox1.Visible = False Then
            If e.KeyCode = Keys.Down Then
                Manufature.Focus()

                e.SuppressKeyPress = True
            End If
            If e.KeyCode = Keys.Enter Then
                Description.Focus()

                e.SuppressKeyPress = True
            End If
        End If
    End Sub

    Private Sub ListBox1_KeyDown(sender As Object, e As KeyEventArgs) Handles ListBox1.KeyDown
        If e.KeyCode = Keys.Enter Then
            If ListBox1.SelectedIndex <> -1 Then
                AutofillSelectedItem()
                ListBox1.Visible = False
                ItemName.Focus()
                e.SuppressKeyPress = True
            End If
        ElseIf e.KeyCode = Keys.Down Then
            If ListBox1.SelectedIndex = ListBox1.Items.Count - 1 Then
                e.SuppressKeyPress = True
                Return ' Do not move selection further down
            End If
        ElseIf e.KeyCode = Keys.Enter Then
            Manufature.Focus()
            ListBox1.Visible = False
        End If
    End Sub

    Private Sub Manufature_KeyDown(sender As Object, e As KeyEventArgs) Handles Manufature.KeyDown
        If e.KeyCode = Keys.Down Then
            Manufature.DroppedDown = True
        ElseIf e.KeyCode = Keys.Enter Then
            Iteamtype.Focus()
        End If
    End Sub


    Private Sub Iteamtype_KeyDown(sender As Object, e As KeyEventArgs) Handles Iteamtype.KeyDown
        If e.KeyCode = Keys.Down Then
            Iteamtype.DroppedDown = True
        ElseIf e.KeyCode = Keys.Enter Then
            Description.Focus()
        End If
    End Sub

    Private Sub Description_KeyDown(sender As Object, e As KeyEventArgs) Handles Description.KeyDown
        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
            Godown.Focus()
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub Godown_KeyDown(sender As Object, e As KeyEventArgs) Handles Godown.KeyDown
        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
            Pakage.Focus()
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub Pakage_KeyDown(sender As Object, e As KeyEventArgs) Handles Pakage.KeyDown
        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
            Unit.Focus()
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub Unit_KeyDown(sender As Object, e As KeyEventArgs) Handles Unit.KeyDown
        If e.KeyCode = Keys.Down OrElse e.KeyCode = Keys.Enter Then
            Button1.Focus()
            e.SuppressKeyPress = True
        End If
    End Sub

    Private Sub TextBox_ItemName_MouseClick(sender As Object, e As MouseEventArgs) Handles ItemName.MouseClick
        If ItemName.Text IsNot "" Then
            ListBox1.Visible = True
        ElseIf ItemName.Text Is "" Then
            ListBox1.Visible = False
        End If
    End Sub
    Private Sub ItemName_TextChanged(sender As Object, e As EventArgs) Handles ItemName.TextChanged
        ' Declare the searchText variable
        Dim searchText As String = ""

        ' Check if the ItemName textbox is not null and not empty
        If ItemName IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(ItemName.Text) Then
            ' Trim the text and assign it to searchText
            searchText = ItemName.Text.Trim()
        End If

        ' Search for items similar to the entered text in the database
        If Not String.IsNullOrWhiteSpace(searchText) Then
            LoadMatchingItems(searchText)
            If ListBox1.Items.Count > 0 Then
                ListBox1.Visible = True ' Show the ListBox when there are matching items
            Else
                ListBox1.Visible = False ' Hide the ListBox when there are no matching items
            End If
        Else
            ListBox1.Visible = False ' Hide the ListBox when the search text is empty
        End If
    End Sub


    Private Sub LoadMatchingItems(searchText As String)
        Try
            ' Clear the list box items
            ListBox1.Items.Clear()

            ' Define your SQL query to search for items similar to the entered text
            Dim query As String = "SELECT master_id, ItemName, Mfrname, Itemtype, Description, Godown, pakage, unit FROM Itemmaster " &
                          "INNER JOIN MfrMaster ON Itemmaster.mfr_id = MfrMaster.mfr_Id " &
                          "INNER JOIN ItemtypeMaster ON Itemmaster.item_id = ItemtypeMaster.item_id " &
                          "WHERE ItemName LIKE @SearchText + '%'"

            ' Create a SqlConnection object
            Using connection As New SqlConnection(connectionString)
                ' Create a SqlCommand object with the query and connection
                Using command As New SqlCommand(query, connection)
                    ' Set the parameter value for the search text
                    command.Parameters.AddWithValue("@SearchText", searchText)

                    ' Open the connection
                    connection.Open()

                    ' Execute the SQL command and retrieve the matching items
                    Using reader As SqlDataReader = command.ExecuteReader()
                        While reader.Read()
                            ' Construct the item string with master_id and add it to the list box
                            Dim itemString As String = $"{reader("master_id")} : {reader("ItemName")} : {reader("Mfrname")} : {reader("Itemtype")} : {reader("Description")} : {reader("Godown")} : {reader("pakage")} : {reader("unit")}"
                            ListBox1.Items.Add(itemString)
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            MessageBox.Show("Error loading matching items: " & ex.Message)
        End Try
    End Sub


    Private Sub ListBox1_ClickOrKeyDown(sender As Object, e As EventArgs) Handles ListBox1.Click, ListBox1.KeyDown
        If ListBox1.SelectedIndex <> -1 AndAlso (TypeOf e Is MouseEventArgs OrElse (TypeOf e Is KeyEventArgs AndAlso DirectCast(e, KeyEventArgs).KeyCode = Keys.Enter)) Then
            AutofillSelectedItem()
        End If
    End Sub

    Private Sub AutofillSelectedItem()
        ' Check if an item is selected in the list box
        If ListBox1.SelectedIndex <> -1 Then
            ' Split the selected item string to extract individual details
            Dim selectedItemDetails As String() = ListBox1.SelectedItem.ToString().Split(":"c)

            ' Autofill the form with the selected item details
            If selectedItemDetails.Length >= 7 Then
                ItemID.Text = selectedItemDetails(0)
                ItemName.Text = selectedItemDetails(1)
                Manufature.Text = selectedItemDetails(2)
                Iteamtype.Text = selectedItemDetails(3)
                Description.Text = selectedItemDetails(4) ' This line should populate the Description field
                Godown.Text = selectedItemDetails(5)
                Pakage.Text = selectedItemDetails(6)
                Unit.Text = selectedItemDetails(7)
                Button1.Visible = False
                Update.Visible = True
            Else
                MessageBox.Show("Error: Incomplete item details.")
            End If

            ' Hide the ListBox after an item is selected
            ListBox1.Visible = False
        End If
    End Sub





    Private Sub Update_Click(sender As Object, e As EventArgs) Handles Update.Click
        If ItemExistsWithDifferentDetails(ItemName.Text, Manufature.Text, Iteamtype.Text) Then
            ' If yes, update the existing item
            UpdateItem()
        Else
            ' If no, behave like the Save button and insert a new item
            SaveItem()
        End If
    End Sub


End Class
